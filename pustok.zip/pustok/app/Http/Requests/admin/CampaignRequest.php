<?php

namespace App\Http\Requests\admin;

use App\Models\Campaign;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;

class CampaignRequest extends FormRequest
{
    public function rules(): array
    {
        $modelId = $this->route('campaign')?->id;

        return [
            'title' => ['required', 'array'],
            'discount_percent' => ['required', 'numeric'],
            'title.*' => ['max:255', function ($attribute, $value, $fail) use ($modelId) {
                $keyValue = Str::of($attribute)->afterLast('.');
                $existingTitles = false;
                $models = Campaign::where('id', '!=', $modelId)->get();
                $existingTitles = false;
                foreach ($models as $model) {
                    $title = $model->getTranslations('title');
                    if (Str::slug($title["$keyValue"]) === Str::slug($value)) {
                        $existingTitles = true;
                        break;
                    }
                }
                if ($existingTitles) {
                    $fail(Str::headline(Str::replace('.', ' ', $attribute)) . ' ' . __('validation.unique'));
                }
                if (!trim($value)) {
                    $fail(Str::headline(Str::replace('.', ' ', $attribute)) . ' ' . __('validation.required'));
                }
            }],
        ];
    }

    public function messages(): array
    {
        return [
            'discount_percent.required' => 'Discount percent ' . __('validation.required'),
            'discount_percent.numeric' => 'Discount percent ' . __('validation.numeric'),
        ];
    }
}
