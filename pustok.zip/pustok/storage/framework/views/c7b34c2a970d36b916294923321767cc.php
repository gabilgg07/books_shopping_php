<?php
if(count(request()->query())){
$queries ='';
foreach(request()->query() as $query=>$value){
$queries = $queries.$query.'='.$value;
}

}
?>


<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section">
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('client.home.index')); ?>"><?php echo e(__('menu.home')); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('menu.shop')); ?></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<main class="inner-page-sec-padding-bottom">
    <div class="container">
        <div class="shop-toolbar mb--30">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-2 col-md-2 col-sm-6">
                    <!-- Product View Mode -->
                    <div class="product-view-mode">
                        <a href="#" class="sorting-btn active" data-target="grid-four">
                            <span class="grid-four-icon">
                                <i class="fas fa-grip-vertical"></i><i class="fas fa-grip-vertical"></i>
                            </span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-4 col-sm-6  mt--10 mt-sm--0">
                    <?php
                    $to = 0;
                    if($books->total()>$books->perPage() && ($books->currentPage() !== $books->lastPage())){
                    $to = $books->currentPage()*$books->perPage();
                    }else{
                    $to = $books->total();
                    }
                    ?>
                    <span class="toolbar-status">
                        <?php echo e(__('word.showing',['from'=>($books->currentPage()-1)*$books->perPage()+1, 'to'=>$to,
                        'sum'=>$books->total(), 'pages'=>$books->lastPage()])); ?>

                    </span>
                </div>
                <div class="col-xl-5 col-lg-5 col-md-5 col-sm-6 mt--10 mt-md--0 ">
                    <div class="sorting-selection">
                        <span><?php echo e(__('word.sort')); ?>:</span>
                        <form action="<?php echo e(url()->current()); ?>" method="GET" id="sortForm">
                            <?php if(count(request()->query())): ?>
                            <?php $__currentLoopData = request()->query(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($query !== 'sort_by'): ?>
                            <input type="hidden" name="<?php echo e($query); ?>" value="<?php echo e($value); ?>" />
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <select class="form-control nice-select sort-select mr-0" name="sort_by"
                                onchange="submitForm()">
                                <option value="" selected="selected"><?php echo e(__('word.default_sort')); ?></option>
                                <option value="az"><?php echo e(__('word.sort')); ?>: <?php echo e(__('word.name')); ?> (<?php echo e(__('word.a_z')); ?>)
                                </option>
                                <option value="za"><?php echo e(__('word.sort')); ?>: <?php echo e(__('word.name')); ?> (<?php echo e(__('word.z_a')); ?>)
                                </option>
                                <option value="p_lh"><?php echo e(__('word.sort')); ?>: <?php echo e(__('word.price_lh')); ?></option>
                                <option value="p_hl"><?php echo e(__('word.sort')); ?>:<?php echo e(__('word.price_hl')); ?></option>
                                <option value="r_hl"><?php echo e(__('word.sort')); ?>:<?php echo e(__('word.rating_h')); ?></option>
                                <option value="r_lh"><?php echo e(__('word.sort')); ?>:<?php echo e(__('word.rating_l')); ?></option>
                            </select>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="shop-product-wrap grid-four with-pagination row space-db--30 shop-border">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-sm-6">
                <div class="product-card">
                    <div class="product-grid-content">
                        <div class="product-header">
                            <a href="" class="author">
                                <?php echo e($book->author); ?>

                            </a>
                            <h3><a
                                    href="<?php echo e(route('client.shop.details', $book->id)); ?>"><?php echo e(Str::limit($book->title,22)); ?></a>
                            </h3>
                        </div>
                        <div class="product-card--body">
                            <div class="card-image">
                                <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="<?php echo e($book->slug); ?> 1">
                                <div class="hover-contents">
                                    <a href="<?php echo e(route('client.shop.details', $book->id)); ?>" class="hover-image">
                                        <?php
                                        $imgHover = $book->images()->first() !== null ?
                                        $book->images()->first()->image :
                                        $book->mainImage()->image;
                                        ?>
                                        <img src="<?php echo e(asset($imgHover)); ?>" alt="<?php echo e($book->slug); ?> 2">
                                    </a>
                                    <div class="hover-btns">
                                        <a href="<?php echo e(route('client.cart.add', $book->id)); ?>" class="single-btn">
                                            <i class="fas fa-shopping-basket"></i>
                                        </a>
                                        <a href="" class="single-btn">
                                            <i class="fas fa-heart"></i>
                                        </a>
                                        <a href="#" data-toggle="modal" data-target="#quickModal"
                                            data-url="<?php echo e(route('client.shop.getDetails', $book->id)); ?>"
                                            class="single-btn detail_modal">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="price-block">
                                <?php if($book->campaign): ?>
                                <span
                                    class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($book->price-($book->price*$book->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                                <del
                                    class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></del>
                                <span class="price-discount"><?php echo e($book->campaign->discount_percent); ?>%</span>
                                <?php else: ?>
                                <span
                                    class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Pagination Block -->

        <?php echo $books->withQueryString()->links('pagination::bootstrap-5'); ?>

        <!-- Modal -->
        <div class="modal fade modal-quick-view" id="quickModal" tabindex="-1" role="dialog"
            aria-labelledby="quickModal" aria-hidden="true">
            <div class="modal-dialog" role="document">

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('.detail_modal').on('click', function(e) {
        e.preventDefault();
        const modalUrl = $(this).data('url');
        $('.product-details-slider').slick('unslick');
        $('.product-slider-nav').slick('unslick');

        $.get(modalUrl, function(data, status) {

            if (status !== 'success') {
                console.error('Error fetching book details:', data.message);
                return;
            }

            $('#quickModal .modal-dialog').html(data);
            $('.product-details-slider').slick({
                slidesToShow: 1,
                arrows: false,
                fade: true,
                swipe: true,
                asNavFor: ".product-slider-nav"
            });

            $('.product-slider-nav').slick({
                infinite: true,
                autoplay: true,
                autoplaySpeed: 8000,
                slidesToShow: 4,
                arrows: true,
                prevArrow: '<button class="slick-prev"><i class="fa fa-chevron-left"></i></button>',
                nextArrow: '<button class="slick-next"><i class="fa fa-chevron-right"></i></button>',
                asNavFor: ".product-details-slider",
                focusOnSelect: true
            });

            $('#quickModal').show();
        });
    });
});

function submitForm() {
    document.getElementById("sortForm").submit();
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('client.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/shop/index.blade.php ENDPATH**/ ?>