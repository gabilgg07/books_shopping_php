<?php
$hero_sliders = $home_index_vm['hero_sliders'];
$galery_categoriers = $home_index_vm['galery_categoriers'];
$best_seller = $home_index_vm['best_seller'];
$featureds = $home_index_vm['featureds'];
$new_arrivals = $home_index_vm['new_arrivals'];
$most_view_books = $home_index_vm['most_view_books'];
?>



<?php $__env->startSection("content"); ?>
<!--=================================
        Hero Area
    ===================================== -->
<?php echo $__env->make("client.home.includes.hero", ['hero_sliders'=>$hero_sliders], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--=================================
        Home Features Section
    ===================================== -->

<!--=================================
        Home Category Gallery
    ===================================== -->
<?php echo $__env->make("client.home.includes.galery", ['categories'=>$galery_categoriers], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--=================================
        Home Two Column Section
    ===================================== -->
<section class=" section-margin">
    <!-- <h1 class="sr-only">Promotion Section</h1> -->
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <?php echo $__env->make("client.home.includes.bestseller", compact('best_seller'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-lg-8">
                <?php echo $__env->make("client.home.includes.tab", compact('featureds','new_arrivals','most_view_books'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<div class="modal fade modal-quick-view" id="quickModal" tabindex="-1" role="dialog" aria-labelledby="quickModal"
    aria-hidden="true">
    <div class="modal-dialog" role="document">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('.detail_modal').on('click', function(e) {
        e.preventDefault();
        const modalUrl = $(this).data('url');
        $('.product-details-slider').slick('unslick');
        $('.product-slider-nav').slick('unslick');

        $.get(modalUrl, function(data, status) {

            if (status !== 'success') {
                console.error('Error fetching book details:', data.message);
                return;
            }

            $('#quickModal .modal-dialog').html(data);
            $('.product-details-slider').slick({
                slidesToShow: 1,
                arrows: false,
                fade: true,
                swipe: true,
                asNavFor: ".product-slider-nav"
            });

            $('.product-slider-nav').slick({
                infinite: true,
                autoplay: true,
                autoplaySpeed: 8000,
                slidesToShow: 4,
                arrows: true,
                prevArrow: '<button class="slick-prev"><i class="fa fa-chevron-left"></i></button>',
                nextArrow: '<button class="slick-next"><i class="fa fa-chevron-right"></i></button>',
                asNavFor: ".product-details-slider",
                focusOnSelect: true
            });

            $('#quickModal').show();
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make("client.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/home/index.blade.php ENDPATH**/ ?>