<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('admin.layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- Main navbar -->
    <?php if (isset($component)) { $__componentOriginale9d350e3cfcd8a683f5be5115c6beb5c = $component; } ?>
<?php $component = App\View\Components\AdminNavComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-nav-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminNavComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9d350e3cfcd8a683f5be5115c6beb5c)): ?>
<?php $component = $__componentOriginale9d350e3cfcd8a683f5be5115c6beb5c; ?>
<?php unset($__componentOriginale9d350e3cfcd8a683f5be5115c6beb5c); ?>
<?php endif; ?>
    <!-- /main navbar -->


    <!-- Page content -->
    <div class="page-content">

        <!-- Main sidebar -->
        <?php echo $__env->make("admin.layouts.partials.main_sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /main sidebar -->


        <!-- Main content -->
        <div class="content-wrapper">

            <!-- Page header -->
            <?php if (isset($component)) { $__componentOriginala2b04e39cc69d5b86b1ca6473645608a = $component; } ?>
<?php $component = App\View\Components\AdminHeaderComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminHeaderComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2b04e39cc69d5b86b1ca6473645608a)): ?>
<?php $component = $__componentOriginala2b04e39cc69d5b86b1ca6473645608a; ?>
<?php unset($__componentOriginala2b04e39cc69d5b86b1ca6473645608a); ?>
<?php endif; ?>
            <!-- /page header -->


            <!-- Content area -->
            <?php echo $__env->yieldContent("content"); ?>
            <!-- /content area -->


            <!-- Footer -->
            <?php if (isset($component)) { $__componentOriginal1c79a072f1c6fb2cdc6796d96251ee8c = $component; } ?>
<?php $component = App\View\Components\AdminFooterComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminFooterComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c79a072f1c6fb2cdc6796d96251ee8c)): ?>
<?php $component = $__componentOriginal1c79a072f1c6fb2cdc6796d96251ee8c; ?>
<?php unset($__componentOriginal1c79a072f1c6fb2cdc6796d96251ee8c); ?>
<?php endif; ?>
            <!-- /footer -->

        </div>
        <!-- /main content -->

    </div>
    <!-- /page content -->

    <?php echo $__env->yieldPushContent('custom_js'); ?>
</body>

</html><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/master.blade.php ENDPATH**/ ?>