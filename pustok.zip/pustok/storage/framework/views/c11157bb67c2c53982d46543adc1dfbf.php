<?php
$model_name = $create_view_model['model_name'];
$table_name = $create_view_model['table_name'];
$langs = $create_view_model['langs'];
?>



<?php $__env->startPush('theme_js'); ?>
<style>
@font-face {
    font-family: summernote;
    font-style: normal;
    font-weight: 400;
    src: url("<?php echo e(asset('admin/global_assets/css/icons/summernote/summernote.eot')); ?>");
    src: url("<?php echo e(asset('admin/global_assets/css/icons/summernote/summernote-1.eot')); ?>") format("embedded-opentype"),
    url("<?php echo e(asset('admin/global_assets/css/icons/summernote/summernote.txt')); ?>") format("woff"),
    url("<?php echo e(asset('admin/global_assets/css/icons/summernote/summernote-1.txt')); ?>") format("truetype")
}
</style>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\switchery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\uniform.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\editors\summernote\summernote.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_inputs.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\editor_summernote.js')); ?>"></script>
<script>
$(window).on('load', function() {
    $("#image_input").change(function(event) {
        var tmppath = URL.createObjectURL(event.target.files[0]);
        $("#image").attr(
            "src",
            URL.createObjectURL(event.target.files[0])
        );
        $("#image").removeClass('d-none');
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("page_title"); ?>
<?php echo e(Str::headline($table_name)); ?> Create
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h5 class="card-title"><?php echo e(Str::headline($table_name)); ?> Create Form</h5>
        </div>
    </div>
    <form action="<?php echo e(route('manager.'.$table_name.'.store')); ?>" method="POST" class="row" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="col-lg-12">
            <?php echo $__env->make('admin.layouts.includes.create_lang_tab_area',['field_name'=>'text_content','langs'=>$langs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('admin.layouts.includes.create_check',['field_name'=>'is_active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('admin.layouts.includes.image_input',['model_name'=>$model_name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('admin.layouts.includes.image',['field_value'=>'',
                    'col_count'=>6,'class_name'=>'img_selected'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="text-right">
                <button type="submit" class="btn btn-primary"><i class="icon-database-insert mr-2"></i> Insert</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/sliders/create.blade.php ENDPATH**/ ?>