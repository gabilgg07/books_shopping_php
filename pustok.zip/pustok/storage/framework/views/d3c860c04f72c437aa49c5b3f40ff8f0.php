<div class="form-group row">
    <label class="col-form-label col-lg-<?php echo e($colLbl); ?>"><?php echo e(Str::headline($field_name)); ?>:</label>
    <div class="col-lg-<?php echo e($colInput); ?>">
        <input type="number" class="form-control" name="<?php echo e($field_name); ?>" value="<?php echo e(old($field_name, $field_value)); ?>"
            step="<?php echo e($step); ?>">
    </div>
    <?php $__errorArgs = [$field_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger ml-2"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/edit_num_input.blade.php ENDPATH**/ ?>