<?php
$user = auth()->user();
?>



<?php $__env->startSection("content"); ?>

<section class="breadcrumb-section">
    <h2 class="sr-only">Site Breadcrumb</h2>
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('client.home.index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Checkout</li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<main id="content" class="page-section inner-page-sec-padding-bottom space-db--20">
    <div class="container">
        <!-- Checkout Form s-->
        <form action="<?php echo e(route('client.account.placeOrder')); ?>" class="checkout-form" method="post">
            <?php echo csrf_field(); ?>
            <div class="row row-40">
                <div class="col-lg-7 mb--20">
                    <!-- Shipping Address -->
                    <div id="shipping-form" class="mb--40">
                        <h4 class="checkout-title">Shipping Address</h4>
                        <div class="row">
                            <div class="col-md-6 col-12 mb--20">
                                <label for="first_name">First Name*</label>
                                <input type="text" placeholder="First Name" id="first_name"
                                    value="<?php echo e($user->first_name); ?>" readonly>
                            </div>
                            <div class="col-md-6 col-12 mb--20">
                                <label for="last_name">Last Name*</label>
                                <input type="text" placeholder="Last Name" id="last_name" value="<?php echo e($user->last_name); ?>"
                                    readonly>
                            </div>
                            <div class="col-md-6 col-12 mb--20">
                                <label for="email">Email Address*</label>
                                <input type="email" placeholder="Email Address" id="email" value="<?php echo e($user->email); ?>"
                                    readonly>
                            </div>
                            <div class="col-md-6 col-12 mb--20">
                                <label for="phone">Phone no*</label>
                                <input type="text" placeholder="Phone number" id="phone" name="phone"
                                    value="<?php echo e($user->phone); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mb--20">
                                <label for="address1">Address*</label>
                                <input type="text" placeholder="Address" id="address" name="address">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 col-12 mb--20">
                                <label for="country">Country*</label>
                                <select class="nice-select" id="country" name="country">
                                    <option value="">Choose country</option>
                                    <option>Azerbaijan</option>
                                    <option>Turkey</option>
                                    <option>Rusian</option>
                                    <option>America</option>
                                    <option>Bangladesh</option>
                                    <option>China</option>
                                    <option>Great Britain</option>
                                    <option>India</option>
                                    <option>Japan</option>
                                </select>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 col-12 mb--20">
                                <label for="city">Town/City*</label>
                                <input type="text" placeholder="Town/City" id="city" name="city">
                                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 col-12 mb--20">
                                <label for="state">State*</label>
                                <input type="text" placeholder="State" id="state" name="state">
                                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 col-12 mb--20">
                                <label for="zip_code">Zip Code*</label>
                                <input type="text" placeholder="Zip Code" id="zip_code" name="zip_code">
                                <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="order-note-block mt--30">
                        <label for="order_notes">Order notes</label>
                        <textarea id="order_notes" cols="30" rows="10" class="order-note" name="order_notes"
                            placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="row">
                        <!-- Cart Total -->
                        <div class="col-12">
                            <div class="checkout-cart-total">
                                <h2 class="checkout-title">YOUR ORDER</h2>
                                <h4>Product <span>Total</span></h4>
                                <ul>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><span
                                            class="left"><?php echo e(((array)json_decode($cart->name))[LaravelLocalization::getCurrentLocale()]); ?>

                                            X <?php echo e($cart->qty); ?></span> <span
                                            class="right"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $cart->price, 2, '.', '')); ?></span>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <!-- <p>Sub Total <span>$104.00</span></p> -->
                                <!-- <p>Shipping Fee <span>$00.00</span></p> -->
                                <!-- <h4>Grand Total <span>$104.00</span></h4> -->
                                <h4>Total
                                    <span><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * Cart::subtotal(), 2, '.', '')); ?></span>
                                </h4>
                                <button class="place-order w-100">Place order</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("client.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/account/checkout.blade.php ENDPATH**/ ?>