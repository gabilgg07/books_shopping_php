<?php $__env->startSection("content"); ?>

<section class="breadcrumb-section">
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('client.home.index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Order Complete</li>
                </ol>
            </nav>
        </div>
    </div>
</section>

<section class="order-complete inner-page-sec-padding-bottom">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="order-complete-message text-center">
                    <h1>Thank you !</h1>
                    <p>Your order has been received.</p>
                </div>
                <ul class="order-details-list">
                    <li>Order Number: <strong><?php echo e($order->order_number); ?></strong></li>
                    <li>Date: <strong><?php echo e($order->created_at->format('F d, Y')); ?></strong></li>
                    <li>Total:
                        <strong><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $order->total_price, 2, '.', '')); ?></strong>
                    </li>
                    <!-- <li>Payment Method: <strong>Cash on Delivery</strong></li> -->
                </ul>
                <!-- <p>Pay with cash upon delivery.</p> -->
                <h3 class="order-table-title">Order Details</h3>
                <div class="table-responsive">
                    <table class="table order-details-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="single-product.html"><?php echo e($orderItem->book->title); ?></a> <strong>×
                                        <?php echo e($orderItem->qty); ?></strong>
                                </td>
                                <td><span><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($orderItem->discount_price ?? $orderItem->price), 2, '.', '')); ?></span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <tr>
                                <td><a href="single-product.html">Supreme Being Icon Glitch T-Shirt</a> <strong>×
                                        1</strong></td>
                                <td><span>$58.00</span></td>
                            </tr> -->
                        </tbody>
                        <tfoot>
                            <!-- <tr>
                                <th>Subtotal:</th>
                                <td><span>$117.00</span></td>
                            </tr>
                            <tr>
                                <th>Payment Method:</th>
                                <td>Cash on Delivery</td>
                            </tr> -->
                            <tr>
                                <th>Total:</th>
                                <td><span><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $order->total_price, 2, '.', '')); ?></span>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("client.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/account/order_complete.blade.php ENDPATH**/ ?>