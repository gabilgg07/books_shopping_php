<div class="form-check form-check-switchery form-check-inline form-check-right mb-2">
    <label class="form-check-label">
        <input type="checkbox" class="form-check-input-switchery" name="<?php echo e($field_name); ?>" data-fouc="" <?php echo e(!old('_token')||old($field_name)?'checked':''); ?>>
        <?php echo e(Str::headline($field_name)); ?> ?
    </label>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/create_check.blade.php ENDPATH**/ ?>