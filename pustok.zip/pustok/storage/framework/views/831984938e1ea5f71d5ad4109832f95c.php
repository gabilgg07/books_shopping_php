<?php $__env->startPush('theme_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\tables\datatables\datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\switchery.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\datatables_basic.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("page_title"); ?>
Orders Index
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card mb-2 d-none alert alert-dismissible" id="alert_message">
        <button type="button" class="close close-alert"><span>×</span></button>
        <span class="msg-text"></span>
    </div>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h5 class="card-title">Orders Table</h5>
            <div style="display: flex; gap: 10px;">
                <div class="box-btn">
                    <a href="<?php echo e(route('manager.orders.deleteds')); ?>" class="btn btn-danger">
                        <i class="mi-delete-sweep mr-1" style="font-size: 18px;"></i>
                        Deleted Orders Table</a>
                </div>
            </div>
        </div>
        <table class="table table-bordered datatable-basic">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>User</th>
                    <th>Qty</th>
                    <th>Total Price</th>
                    <th>Is Accept</th>
                    <th>Image</th>
                    <th class="w-auto">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td>
                        <?php echo e($order->user->first_name); ?> <?php echo e($order->user->last_name); ?>

                    </td>
                    <td><?php echo e($order->total_count); ?></td>
                    <td>
                        <?php echo e(number_format($order->total_price, 2, '.', '')); ?>

                    </td>
                    <?php if($order->is_accepted !== null): ?>
                    <?php if($order->is_accepted === true): ?>
                    <td><span class="text-success">Approved</span></td>
                    <?php else: ?>
                    <td><span class="text-danger">Rejected</span></td>
                    <?php endif; ?>
                    <?php else: ?>
                    <td><span class="text-warning">Pending</span></td>
                    <?php endif; ?>
                    <td width='200'>
                        <?php if($order->user->image): ?>
                        <img src="<?php echo e($order->user->image); ?>" alt="" class="img-fluid w-100" style="object-fit: cover; object-position: center; height:100px;">
                        <?php endif; ?>
                    </td>
                    <td class="text-right">

                        <?php if($order->is_accepted !== null): ?>
                        <?php if($order->is_accepted === true): ?>
                        <a href="<?php echo e(route('manager.order.reject',$order->id)); ?>" class="btn btn-danger mb-1"><i class="icon-pencil3 mr-2"></i>
                            To Reject</a>
                        <?php else: ?>
                        <a href="<?php echo e(route('manager.order.accept', $order->id)); ?>" class="btn btn-success mb-1"><i class="mi-info mr-2"></i>To Accept</a>
                        <?php endif; ?>
                        <?php else: ?>
                        <a href="<?php echo e(route('manager.order.accept', $order->id)); ?>" class="btn btn-success mb-1"><i class="mi-info mr-2"></i>To Accept</a>
                        <a href="<?php echo e(route('manager.order.reject',$order->id)); ?>" class="btn btn-danger mb-1"><i class="icon-pencil3 mr-2"></i>
                            To Reject</a>
                        <?php endif; ?>
                        <form onsubmit="return confirm('Are you sure?')" method="post" action="<?php echo e(route('manager.order.destroy', $order->id)); ?>" class="d-inline-block">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-danger mb-1"><i class="mi-delete mr-2 mb-1"></i>
                                Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/order_list.blade.php ENDPATH**/ ?>