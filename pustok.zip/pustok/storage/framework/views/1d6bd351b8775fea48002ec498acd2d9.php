<div class="col-lg-6">
    <div class="card card-body bg-light rounded-left-0 border-left-3 border-left-<?php echo e($color); ?>">
        <blockquote class="blockquote d-flex mb-0">
            <?php if($user->image): ?>
            <div class="mr-3">
                <img class="rounded-circle" src="<?php echo e($user->image); ?>" width="46" height="46" alt="">
            </div>
            <?php endif; ?>

            <div>
                <p class="mb-1">This <?php echo e(Str::headline($model_name)); ?> <?php echo e($action_name); ?> by
                    <cite><?php echo e($user->first_name.' '.$user->last_name); ?></cite>
                </p>
                <footer class="blockquote-footer"><?php echo e(Str::headline($action_name)); ?> At:
                    <cite><?php echo e($date); ?></cite>
                </footer>
            </div>
        </blockquote>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/show_user.blade.php ENDPATH**/ ?>