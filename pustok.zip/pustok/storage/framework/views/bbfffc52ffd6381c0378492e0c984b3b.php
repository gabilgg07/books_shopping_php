<?php $__env->startPush("theme_js"); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\switchery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\uniform.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_inputs.js')); ?>"></script>
<script>
$(window).on('load', function() {
    $(".image_input").change(function(event) {
        var tmppath = URL.createObjectURL(event.target.files[0]);
        $(`.${$(this).attr('name')}`).attr(
            "src",
            URL.createObjectURL(event.target.files[0])
        );
        $(`.${$(this).attr('name')}`).removeClass('d-none');
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("page_title"); ?>
Settings Edit
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h5 class="card-title">Settings Edit</h5>
        </div>
        <?php if($errors->any()): ?>
        <div class="card-body">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="text-danger"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
    <div class="card p-3">
        <form action="<?php echo e(route('manager.settings.update')); ?>" method="POST" class="row" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-12">
                        <?php echo $__env->make('admin.layouts.includes.edit_lang_tab',['field_name'=>'location_title','langs'=>$langs,'field_value'=>$location_title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-lg-12">
                        <?php echo $__env->make('admin.layouts.includes.edit_lang_tab_area',['field_name'=>'location_desc','langs'=>$langs,'field_value'=>$location_desc], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-lg-12">
                        <?php echo $__env->make('admin.layouts.includes.edit_lang_tab_area',['field_name'=>'copy_heading','langs'=>$langs,'field_value'=>$copy_heading], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-lg-12">
                        <?php echo $__env->make('admin.layouts.includes.edit_lang_tab_area',['field_name'=>'copy_text','langs'=>$langs,'field_value'=>$copy_text], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('admin.layouts.includes.edit_check',['field_name'=>'is_active','field_value'=>$model->is_active], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_num_input',['field_name'=>'shipping_percent',
                        'field_value'=>$model->shipping_percent,'step'=>'1', 'colLbl'=>2,
                        'colInput'=>10]
                        , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'address','field_value'=>$model->address], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'email','field_value'=>$model->email], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'phone','field_value'=>$model->phone], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'facebook','field_value'=>$model->facebook], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'twitter','field_value'=>$model->twitter], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'google_plus','field_value'=>$model->google_plus], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'youtube','field_value'=>$model->youtube], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'instagram','field_value'=>$model->instagram], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label class="col-form-label col-lg-3">Upload Logo Image:</label>
                                        <div class="col-lg-9">
                                            <input type="file" id="image_input"
                                                class="form-control-uniform-custom image_input" data-fouc=""
                                                name="logo_image">
                                            <?php $__errorArgs = ['logo_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <?php $__errorArgs = ['validation.mimes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            <span class="form-text text-muted">Accepted formats: gif, png, jpg, jpeg,
                                                svg, webp. Max
                                                file
                                                size 2Mb</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label class="col-form-label col-lg-3">Upload Footer Logo Image:</label>
                                        <div class="col-lg-9">
                                            <input type="file" id="image_input"
                                                class="form-control-uniform-custom image_input" data-fouc=""
                                                name="logo_footer_image">
                                            <?php $__errorArgs = ['logo_footer_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <?php $__errorArgs = ['validation.mimes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            <span class="form-text text-muted">Accepted formats: gif, png, jpg, jpeg,
                                                svg, webp. Max
                                                file
                                                size 2Mb</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">

                            <label>Logo Image:</label>
                            <?php echo $__env->make('admin.layouts.includes.image',['field_value'=>asset($model->logo_image),
                            'col_count'=>6,'class_name'=>'img_selected logo_image'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-lg-6">

                            <label>Logo Footer Image:</label>
                            <?php echo $__env->make('admin.layouts.includes.image',['field_value'=>asset($model->logo_footer_image),
                            'col_count'=>6,'class_name'=>'img_selected logo_footer_image'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="text-right">
                    <button type="submit" class="btn btn-primary"><i class="icon-database-edit2 mr-2"></i>
                        Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/settings/edit.blade.php ENDPATH**/ ?>