<div class="row pt--30">
    <div class="col-md-12">
        <div class="pagination-block">
            <ul class="pagination-btns flex-center">
                <li><a href="" class="single-btn prev-btn ">|<i class="zmdi zmdi-chevron-left"></i> </a>
                </li>
                <li><a href="" class="single-btn prev-btn "><i class="zmdi zmdi-chevron-left"></i> </a>
                </li>
                <li class="active"><a href="" class="single-btn">1</a></li>
                <li><a href="" class="single-btn">2</a></li>
                <li><a href="" class="single-btn">3</a></li>
                <li><a href="" class="single-btn">4</a></li>
                <li><a href="" class="single-btn next-btn"><i class="zmdi zmdi-chevron-right"></i></a>
                </li>
                <li><a href="" class="single-btn next-btn"><i class="zmdi zmdi-chevron-right"></i>|</a>
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/partials/pagination.blade.php ENDPATH**/ ?>