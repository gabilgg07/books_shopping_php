<div class="card">
    <div class="card-body row">
        <img src="<?php echo e($field_value??''); ?>" alt="" id="image" class="<?php echo e($field_value?'':'d-none'); ?> <?php echo e($class_name); ?>">
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/big_img.blade.php ENDPATH**/ ?>