<!DOCTYPE html>
<html lang="zxx">

<head>
    <?php echo $__env->make("client.layouts.partials.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="site-wrapper" id="top">
        <?php if (isset($component)) { $__componentOriginalc51af82fb563328e55227eacdc75d53e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc51af82fb563328e55227eacdc75d53e = $attributes; } ?>
<?php $component = App\View\Components\ClientHeaderComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('client-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ClientHeaderComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc51af82fb563328e55227eacdc75d53e)): ?>
<?php $attributes = $__attributesOriginalc51af82fb563328e55227eacdc75d53e; ?>
<?php unset($__attributesOriginalc51af82fb563328e55227eacdc75d53e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51af82fb563328e55227eacdc75d53e)): ?>
<?php $component = $__componentOriginalc51af82fb563328e55227eacdc75d53e; ?>
<?php unset($__componentOriginalc51af82fb563328e55227eacdc75d53e); ?>
<?php endif; ?>
        <?php echo $__env->make("client.layouts.partials.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("client.layouts.partials.sticky", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent("content"); ?>
    </div>



    <!--=================================
    Footer
===================================== -->

    <?php if (isset($component)) { $__componentOriginaldbc96a403978fa830273ae4836363ea3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbc96a403978fa830273ae4836363ea3 = $attributes; } ?>
<?php $component = App\View\Components\BrandsComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('brands-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BrandsComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbc96a403978fa830273ae4836363ea3)): ?>
<?php $attributes = $__attributesOriginaldbc96a403978fa830273ae4836363ea3; ?>
<?php unset($__attributesOriginaldbc96a403978fa830273ae4836363ea3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbc96a403978fa830273ae4836363ea3)): ?>
<?php $component = $__componentOriginaldbc96a403978fa830273ae4836363ea3; ?>
<?php unset($__componentOriginaldbc96a403978fa830273ae4836363ea3); ?>
<?php endif; ?>
    <?php echo $__env->make("client.layouts.partials.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("client.layouts.partials.foot", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/master.blade.php ENDPATH**/ ?>