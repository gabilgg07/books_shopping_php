<!-- Use Minified Plugins Version For Fast Page Load -->
<script src="<?php echo e(asset('client/assets/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('client/assets/js/ajax-mail.js')); ?>"></script>
<?php echo $__env->yieldPushContent("scripts"); ?>
<script src="<?php echo e(asset('client/assets/js/custom.js')); ?>"></script><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/partials/foot.blade.php ENDPATH**/ ?>