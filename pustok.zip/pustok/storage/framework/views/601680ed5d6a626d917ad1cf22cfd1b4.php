<?php
$count = 0;
?>

<div class="site-header header-4 mb--20 d-none d-lg-block">

    <div class="header-middle pt--10 pb--10">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3">
                    <a href="<?php echo e(route('client.home.index')); ?>" class="site-brand">
                        <img src="<?php echo e(asset($settings->logo_image)); ?>" alt="">
                    </a>
                </div>
                <div class="col-lg-4">
                    <div class="header-search-block">
                        <input type="text" placeholder="<?php echo e(__('search.placeholder')); ?>">
                        <button><?php echo e(__('search.btn')); ?></button>
                    </div>
                </div>
                <d iv class="col-lg-5">
                    <div class="main-navigation flex-lg-right">
                        <div class="cart-widget">
                            <div class="login-block">
                                <?php if($user && !$user->is_admin): ?>
                                <a href="<?php echo e(route('client.account.index')); ?>" class="font-weight-bold"><?php echo e($user->first_name." ".$user->last_name); ?></a>
                                <br>
                                <span><?php echo e(__('word.or')); ?></span><a href="<?php echo e(route('client.account.logout')); ?>"><?php echo e(__('word.logout')); ?></a>
                                <?php else: ?>
                                <a href="<?php echo e(route('auth.signin')); ?>" class="font-weight-bold"><?php echo e(__('word.login')); ?></a>
                                <br>
                                <span><?php echo e(__('word.or')); ?></span><a href="<?php echo e(route('auth.signup')); ?>"><?php echo e(__('word.register')); ?></a>
                                <?php endif; ?>
                            </div>
                            <div class="langs-block">
                                <p class="lang">
                                    <?php if($currentLang->image): ?>
                                    <img src="<?php echo e($currentLang->image); ?>" class="img-flag mr-2" alt="<?php echo e($currentLang->code.'-'.$currentLang->country); ?>">
                                    <?php endif; ?>
                                    <?php echo e(Str::upper($currentLang->code)); ?> <i class="ml-1 fas fa-angle-down "></i>
                                </p>
                                <ul class="langs">
                                    <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($currentLang->code !== $lang->code): ?>
                                    <li class="lang-item">
                                        <a rel="alternate" hreflang="<?php echo e($lang->code); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($lang->code, null, [], true)); ?>">
                                            <?php if($lang->image): ?>
                                            <img src="<?php echo e($lang->image); ?>" class="img-flag mr-2" alt="<?php echo e($lang->code.'-'.$lang->country); ?>">
                                            <?php endif; ?>
                                            <?php echo e(Str::upper($lang->code)); ?>

                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="cart-block">
                                <div class="cart-total">
                                    <span class="text-number">
                                        <?php echo e(Cart::count()); ?>

                                    </span>
                                    <span class="text-item">
                                        <?php echo e(__('card.title')); ?>

                                    </span>
                                    <span class="price">
                                        <?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice*Cart::subtotal(), 2, '.','')); ?>

                                        <i class="fas fa-chevron-down"></i>
                                    </span>
                                </div>
                                <div class="cart-dropdown-block">
                                    <div class=" single-cart-block ">
                                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php
                                        $titles = (array)json_decode($cart->name);
                                        if($titles && count($titles)){
                                        $title = $titles[LaravelLocalization::getCurrentLocale()];
                                        }
                                        $count++;
                                        if($count>=4){
                                        break;
                                        }
                                        ?>
                                        <div class="cart-product">
                                            <a href="<?php echo e(route('client.shop.details',$cart->id)); ?>" class="image">
                                                <img src="<?php echo e(asset($cart->options['image'])); ?>" alt="">
                                            </a>
                                            <div class="content">
                                                <h3 class="title"><a href="<?php echo e(route('client.shop.details',$cart->id)); ?>">
                                                        <?php echo e($title ?? $cart->name); ?></a>
                                                </h3>
                                                <p class="price"><span class="qty"><?php echo e($cart->qty); ?> ×</span>
                                                    <?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice*$cart->price, 2, '.', '')); ?>

                                                </p>
                                                <a href="<?php echo e(route('client.cart.remove',$cart->rowId)); ?>" class="cross-btn"><i class="fas fa-times"></i></a>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class=" single-cart-block ">
                                        <div class="btn-block">
                                            <a href="<?php echo e(route('client.cart')); ?>" class="btn"><?php echo e(__('card.view')); ?><i class="fas fa-chevron-right"></i></a>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </d>
            </div>
        </div>
    </div>
    <div class="header-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3">
                    <nav class="category-nav primary-nav <?php echo e(request()->routeIs('client.home.index') ? 'show' : ''); ?>">
                        <div>
                            <a href="javascript:void(0)" class="category-trigger"><i class="fa fa-bars"></i><?php echo e(__('categories.title')); ?></a>
                            <?php if (isset($component)) { $__componentOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f = $attributes; } ?>
<?php $component = App\View\Components\ClientCategoriesComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('client-categories-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ClientCategoriesComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f)): ?>
<?php $attributes = $__attributesOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f; ?>
<?php unset($__attributesOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f)): ?>
<?php $component = $__componentOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f; ?>
<?php unset($__componentOriginalc5cd35f8bc5c714d70c52ae0b8ccdd1f); ?>
<?php endif; ?>
                        </div>
                    </nav>
                </div>
                <div class="col-lg-3">
                    <div class="header-phone ">
                        <div class="icon">
                            <i class="fas fa-headphones-alt"></i>
                        </div>
                        <div class="text">
                            <p><?php echo e(__('free.support')); ?></p>
                            <p class="font-weight-bold number"><?php echo e($settings->phone); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="main-navigation flex-lg-right">
                        <ul class="main-menu menu-right li-last-0">
                            <?php echo $__env->make("client.layouts.partials.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/components/client-header-component.blade.php ENDPATH**/ ?>