<div class="home-left-side text-center text-lg-left">
    <div class="single-block">
        <h3 class="home-sidebar-title">
            <?php echo e(__('best.sellers')); ?>

        </h3>
        <div class="product-slider product-list-slider multiple-row sb-slick-slider home-4-left-sidebar" data-slick-setting='{
                                            "autoplay": true,
                                            "autoplaySpeed": 8000,
                                            "slidesToShow":1,
                                            "rows":4,
                                            "dots":true
                                        }' data-slick-responsive='[
                                            {"breakpoint":1200, "settings": {"slidesToShow": 1} },
                                            {"breakpoint":992, "settings": {"slidesToShow": 2, "rows":2} },
                                            {"breakpoint":768, "settings": {"slidesToShow": 2, "rows":2} },
                                            {"breakpoint":575, "settings": {"slidesToShow": 1} },
                                            {"breakpoint":490, "settings": {"slidesToShow": 1} }
                                        ]'>

            <?php $__currentLoopData = $best_seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-slide">
                <div class="product-card card-style-list">
                    <div class="card-image">
                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="<?php echo e($book->slug); ?> 1">
                    </div>
                    <div class="product-card--body">
                        <div class="product-header">
                            <a href="#" class="author">
                                <?php echo e($book->author); ?>

                            </a>
                            <h3><a href="<?php echo e(route('client.shop.details', $book->id)); ?>"><?php echo e(Str::limit($book->title,22)); ?></a>
                            </h3>
                        </div>
                        <div class="price-block">
                            <?php if($book->campaign): ?>
                            <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($book->price-($book->price*$book->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                            <del class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></del>
                            <span class="price-discount"><?php echo e($book->campaign->discount_percent); ?>%</span>
                            <?php else: ?>
                            <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/home/includes/bestseller.blade.php ENDPATH**/ ?>