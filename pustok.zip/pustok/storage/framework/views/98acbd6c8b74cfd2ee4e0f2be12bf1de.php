<?php if(session('message')): ?>
<div class="card mb-2 alert alert-<?php echo e(session('type')); ?> alert-dismissible">
    <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
    <?php echo session('message'); ?>

</div>
<?php endif; ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/alert.blade.php ENDPATH**/ ?>