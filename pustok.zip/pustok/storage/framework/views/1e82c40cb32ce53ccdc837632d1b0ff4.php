<?php
$models = $component_model['models'];
?>

<!--=================================
  Brands Slider
===================================== -->
<section class="section-margin">
    <!-- <h2 class="sr-only">Brand Slider</h2> -->
    <div class="container">
        <div class="brand-slider sb-slick-slider border-top border-bottom" data-slick-setting='{
                                            "autoplay": true,
                                            "autoplaySpeed": 8000,
                                            "slidesToShow": 5,
                                            "loop": true
                                            }' data-slick-responsive='[
                {"breakpoint":992, "settings": {"slidesToShow": 4} },
                {"breakpoint":768, "settings": {"slidesToShow": 3} },
                {"breakpoint":575, "settings": {"slidesToShow": 3} },
                {"breakpoint":480, "settings": {"slidesToShow": 2} },
                {"breakpoint":320, "settings": {"slidesToShow": 1} }
            ]'>
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-slide">
                <img src="<?php echo e(asset($model->image)); ?>" alt="brands">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- <div class="single-slide">
                <img src="<?php echo e(asset('client/assets/image/others/brand-2.jpg')); ?>" alt="">
            </div>
            <div class="single-slide">
                <img src="<?php echo e(asset('client/assets/image/others/brand-3.jpg')); ?>" alt="">
            </div>
            <div class="single-slide">
                <img src="<?php echo e(asset('client/assets/image/others/brand-4.jpg')); ?>" alt="">
            </div>
            <div class="single-slide">
                <img src="<?php echo e(asset('client/assets/image/others/brand-5.jpg')); ?>" alt="">
            </div>
            <div class="single-slide">
                <img src="<?php echo e(asset('client/assets/image/others/brand-6.jpg')); ?>" alt="">
            </div>
            <div class="single-slide">
                <img src="<?php echo e(asset('client/assets/image/others/brand-1.jpg')); ?>" alt="">
            </div>
            <div class="single-slide">
                <img src="<?php echo e(asset('client/assets/image/others/brand-2.jpg')); ?>" alt="">
            </div> -->
        </div>
    </div>
</section><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/components/brands-component.blade.php ENDPATH**/ ?>