<div class="form-group row">
    <label class="col-form-label col-lg-3">Upload <?php echo e(Str::headline($model_name)); ?> Image:</label>
    <div class="col-lg-9">
        <input type="file" id="image_input" class="form-control-uniform" data-fouc="" name="image">
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <label class="validation-invalid-label"><?php echo e($message); ?></label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <span class="form-text text-muted">Accepted formats: gif, png, jpg, jpeg, svg, webp. Max
            file
            size 2Mb</span>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/image_input.blade.php ENDPATH**/ ?>