<?php $__env->startSection("content"); ?>
<section class="breadcrumb-section">
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('client.home.index')); ?>"><?php echo e(__('menu.home')); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('word.product_details')); ?></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<main class="inner-page-sec-padding-bottom">
    <div class="container">
        <div class="row mb--60">
            <div class="col-lg-5 mb--30">
                <!-- Product Details Slider Big Image-->
                <div class="product-details-slider sb-slick-slider arrow-type-two" data-slick-setting='{
                    "infinite":<?php echo e(count($book->images())?'true':'false'); ?>,
              "slidesToShow": 1,
              "arrows": false,
              "fade": true,
              "draggable": false,
              "swipe": false,
              "asNavFor": ".product-slider-nav"
              }'>
                    <div class="single-slide">
                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="<?php echo e($book->slug); ?>-1" />
                    </div>
                    <?php $__currentLoopData = $book->images(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-slide">
                        <img src="<?php echo e(asset($img->image)); ?>" alt="<?php echo e($book->slug); ?>-<?php echo e($key+2); ?>" />
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Product Details Slider Nav -->
                <?php if(count($book->images())): ?>
                <div class="mt--30 product-slider-nav sb-slick-slider arrow-type-two" data-slick-setting='{
            "infinite":true,
              "autoplay": true,
              "autoplaySpeed": 8000,
              "slidesToShow": <?php echo e(count($book->images())-1<5?count($book->images())-1:4); ?>,
              "arrows": true,
              "prevArrow":{"buttonClass": "slick-prev","iconClass":"fa fa-chevron-left"},
              "nextArrow":{"buttonClass": "slick-next","iconClass":"fa fa-chevron-right"},
              "asNavFor": ".product-details-slider",
              "focusOnSelect": true
              }'>
                    <div class="single-slide">
                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="<?php echo e($book->slug); ?>-1" />
                    </div>
                    <?php $__currentLoopData = $book->images(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-slide">
                        <img src="<?php echo e(asset($img->image)); ?>" alt="<?php echo e($book->slug); ?>-<?php echo e($key+2); ?>" />
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-7">
                <div class="product-details-info pl-lg--30">
                    <!-- <p class="tag-block">
                        Tags: <a href="#">Movado</a>, <a href="#">Omega</a>
                    </p> -->
                    <h3 class="product-title">
                        <?php echo e($book->title); ?>

                    </h3>
                    <ul class="list-unstyled">
                        <!-- <li>Ex Tax: <span class="list-value"> <?php echo e(__('symbol.currency')); ?>60.24</span></li> -->
                        <li>
                            <?php echo e(__('word.category')); ?>:
                            <a href="<?php echo e(route('client.shop.index', $book->category->slug)); ?>"
                                class="list-value font-weight-bold"> <?php echo e($book->category->title); ?></a>
                        </li>
                        <?php if($book->campaign): ?>
                        <li>
                            <?php echo e(__('word.campaign')); ?>:
                            <a href="<?php echo e(route('client.shop.index', ['campaign_id'=>$book->campaign->id])); ?>"
                                class="list-value font-weight-bold"> <?php echo e($book->campaign->title); ?></a>
                        </li>
                        <?php endif; ?>
                        <!-- <li>Product Code: <span class="list-value"> model1</span></li> -->
                        <!-- <li>Reward Points: <span class="list-value"> 200</span></li> -->
                        <li>
                            <?php echo e(__('word.availability')); ?>: <?php if($book->count): ?>
                            <span class="list-value"> <?php echo e(__('word.in_stock')); ?></span>
                            <?php else: ?>
                            <span class="list-value"> <?php echo e(__('word.out_stock')); ?></span>
                            <?php endif; ?>
                        </li>
                    </ul>
                    <div class="price-block">
                        <?php if($book->campaign): ?>
                        <span
                            class="price-new"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice*($book->price-($book->price*$book->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                        <del
                            class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice*$book->price, 2, '.', '')); ?></del>
                        <?php else: ?>
                        <span
                            class="price-new"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice*$book->price, 2, '.', '')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="rating-widget">
                        <div class="rating-block">
                            <?php for($i = 0; $i< 5; $i++): ?> <?php if($i < (int)round($book->rate)): ?>
                                <span class="fas fa-star star_on"></span>
                                <?php else: ?>
                                <span class="fas fa-star"></span>
                                <?php endif; ?>
                                <?php endfor; ?>
                        </div>
                        <div class="review-widget">
                            <a href="">(<?php echo e($book->rate); ?> <?php echo e(__('word.reviews')); ?>)</a> <span>|</span>
                            <a href=""><?php echo e(__('review.write')); ?></a>
                        </div>
                    </div>
                    <article class="product-details-article">
                        <p>
                            <?php echo e($book->short_desc); ?>

                        </p>
                    </article>
                    <div class="add-to-cart-row">
                        <form action="<?php echo e(route('client.cart.update.modal')); ?>" class="row" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="count-input-block">
                                <span class="widget-label"><?php echo e(__('word.qty')); ?></span>
                                <input type="number" name="qty" class="form-control text-center" value="1">
                                <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                            </div>
                            <div class="add-cart-btn">
                                <button class="btn btn-outlined--primary"><span
                                        class="plus-icon">+</span><?php echo e(__('cart.add')); ?></button>
                            </div>
                        </form>
                    </div>
                    <div class="compare-wishlist-row">
                        <a href="" class="add-link"><i class="fas fa-heart"></i><?php echo e(__('wish.add')); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="sb-custom-tab review-tab section-padding">
            <ul class="nav nav-tabs nav-style-2" id="myTab2" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="tab1" data-toggle="tab" href="#tab-1" role="tab"
                        aria-controls="tab-1" aria-selected="true">
                        <?php echo e(__('word.description')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="tab2" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2"
                        aria-selected="true">
                        <?php echo e(__('word.reviews')); ?> (<?php echo e($book->reviews->count()); ?>)
                    </a>
                </li>
            </ul>
            <div class="tab-content space-db--20" id="myTabContent">
                <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab1">
                    <article class="review-article">
                        <p>
                            <?php echo e($book->long_desc); ?>

                        </p>
                    </article>
                </div>
                <div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab2">
                    <div class="review-wrapper">
                        <?php $__currentLoopData = $book->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="review-comment mb--20">
                            <div class="avatar">
                                <img src="<?php echo e(asset($review->user->image?$review->user->image:'client/assets/image/user_default_photo.png')); ?>"
                                    alt="" />
                            </div>
                            <div class="text">
                                <div class="rating-block mb--15">
                                    <?php for($i = 0; $i< 5; $i++): ?> <?php if($i < $review->rate): ?>
                                        <span class="ion-android-star-outline star_on"></span>
                                        <?php else: ?>
                                        <span class="ion-android-star-outline"></span>
                                        <?php endif; ?>
                                        <?php endfor; ?>
                                </div>
                                <h6 class="author">
                                    <?php echo e($review->user->first_name); ?> <?php echo e($review->user->last_name); ?>–
                                    <span class="font-weight-400"><?php echo e($review->created_at->format('F d, Y')); ?></span>
                                </h6>
                                <?php if($review->comment): ?>
                                <p>
                                    <?php echo e($review->comment); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <h2 class="title-lg mb--20 pt--15">ADD A REVIEW</h2>
                        <form action="<?php echo e(route('client.shop.addReview')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="rating-row pt-2">
                                <p class="d-block">Your Rating</p>
                                <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <br />
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="hidden" name="rate" class="rate_input">
                                <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                <span class="rating-widget-block">
                                    <input type="radio" name="star" data-rate="5" id="star1" />
                                    <label for="star1"></label>
                                    <input type="radio" name="star" data-rate="4" id="star2" />
                                    <label for="star2"></label>
                                    <input type="radio" name="star" data-rate="3" id="star3" />
                                    <label for="star3"></label>
                                    <input type="radio" name="star" data-rate="2" id="star4" />
                                    <label for="star4"></label>
                                    <input type="radio" name="star" data-rate="1" id="star5" />
                                    <label for="star5"></label>
                                </span>
                                <?php $__errorArgs = ['star'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <br />
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="mt--15 site-form">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="message">Comment</label>
                                                <textarea name="message" id="message" cols="30" rows="10"
                                                    class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="submit-btn">
                                                <button class="btn btn-black post_btn">Post Comment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="tab-product-details">
  <div class="brand">
    <img src="image/others/review-tab-product-details" alt="">
  </div>
  <h5 class="meta">Reference <span class="small-text">demo_5</span></h5>
  <h5 class="meta">In stock <span class="small-text">297 Items</span></h5>
  <section class="product-features">
    <h3 class="title">Data sheet</h3>
    <dl class="data-sheet">
      <dt class="name">Compositions</dt>
      <dd class="value">Viscose</dd>
      <dt class="name">Styles</dt>
      <dd class="value">Casual</dd>
      <dt class="name">Properties</dt>
      <dd class="value">Maxi Dress</dd>
    </dl>
  </section>
</div> -->
    </div>
    <!--=================================
    RELATED PRODUCTS BOOKS
===================================== -->
    <section class="">
        <div class="container">
            <div class="section-title section-title--bordered">
                <h2>RELATED PRODUCTS</h2>
            </div>
            <div class="product-slider sb-slick-slider slider-border-single-row related_books" data-slick-setting='{
                "autoplay": true,
                "autoplaySpeed": 8000,
                "slidesToShow": 4,
                "dots":true
            }' data-slick-responsive='[
                {"breakpoint":1200, "settings": {"slidesToShow": 4} },
                {"breakpoint":992, "settings": {"slidesToShow": 3} },
                {"breakpoint":768, "settings": {"slidesToShow": 2} },
                {"breakpoint":480, "settings": {"slidesToShow": 1} }
            ]'>
                <?php $__currentLoopData = $relatedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-slide">
                    <div class="product-card">
                        <div class="product-header">
                            <a href="" class="author"> <?php echo e($item->author); ?> </a>
                            <h3>
                                <a
                                    href="<?php echo e(route('client.shop.details', $item->id)); ?>"><?php echo e(Str::limit($item->title,22)); ?></a>
                            </h3>
                        </div>
                        <div class="product-card--body">
                            <div class="card-image">
                                <img src="<?php echo e(asset($item->mainImage()->image)); ?>" alt="<?php echo e($item->slug); ?> 1" />
                                <div class="hover-contents">
                                    <a href="<?php echo e(route('client.shop.details', $item->id)); ?>" class="hover-image">
                                        <?php
                                        $imgHover = $item->images()->first() !== null ?
                                        $item->images()->first()->image :
                                        $item->mainImage()->image;
                                        ?>
                                        <img src="<?php echo e(asset($imgHover)); ?>" alt="<?php echo e($item->slug); ?> 2" />
                                    </a>
                                    <div class="hover-btns">
                                        <a href="<?php echo e(route('client.cart.add', $item->id)); ?>" class="single-btn">
                                            <i class="fas fa-shopping-basket"></i>
                                        </a>
                                        <a href="" class="single-btn">
                                            <i class="fas fa-heart"></i>
                                        </a>
                                        <a href="#" data-toggle="modal" data-target="#quickModal"
                                            data-url="<?php echo e(route('client.shop.getDetails', $item->id)); ?>"
                                            class="single-btn detail_modal">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="price-block">
                                <?php if($item->campaign): ?>

                                <span
                                    class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($item->price-($item->price*$item->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                                <del
                                    class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $item->price, 2, '.', '')); ?></del>
                                <span class="price-discount"><?php echo e($item->campaign->discount_percent); ?>%</span>
                                <?php else: ?>
                                <span
                                    class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $item->price, 2, '.', '')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade modal-quick-view" id="quickModal" tabindex="-1" role="dialog" aria-labelledby="quickModal"
        aria-hidden="true">
        <div class="modal-dialog" role="document">

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('.detail_modal').on('click', function(e) {
        e.preventDefault();
        const modalUrl = $(this).data('url');
        $('.product-details-slider').slick('unslick');
        $('.product-slider-nav').slick('unslick');

        $.get(modalUrl, function(data, status) {

            if (status !== 'success') {
                console.error('Error fetching book details:', data.message);
                return;
            }

            $('#quickModal .modal-dialog').html(data);
            $('.product-details-slider').slick({
                slidesToShow: 1,
                arrows: false,
                fade: true,
                swipe: true,
                asNavFor: ".product-slider-nav"
            });

            $('.product-slider-nav').slick({
                infinite: true,
                autoplay: true,
                autoplaySpeed: 8000,
                slidesToShow: 4,
                arrows: true,
                prevArrow: '<button class="slick-prev"><i class="fa fa-chevron-left"></i></button>',
                nextArrow: '<button class="slick-next"><i class="fa fa-chevron-right"></i></button>',
                asNavFor: ".product-details-slider",
                focusOnSelect: true
            });

            $('#quickModal').show();
        });
    });

    $('.rating-widget-block input').on('click', function(e) {
        $('.rate_input').val($(this).data('rate'));
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make("client.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/shop/details.blade.php ENDPATH**/ ?>