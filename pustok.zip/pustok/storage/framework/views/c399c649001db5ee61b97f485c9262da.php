<?php
$model_name = $create_view_model['model_name'];
$table_name = $create_view_model['table_name'];
$langs = $create_view_model['langs'];
?>



<?php $__env->startPush('theme_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\switchery.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_checkboxes_radios.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush("page_title"); ?>
<?php echo e(Str::headline($table_name)); ?> Create
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h5 class="card-title"><?php echo e(Str::headline($table_name)); ?> Create Form</h5>
        </div>
    </div>
    <form action="<?php echo e(route('manager.'.$table_name.'.store')); ?>" method="POST" class="row">
        <?php echo csrf_field(); ?>
        <div class="col-lg-8">
            <?php echo $__env->make('admin.layouts.includes.create_lang_tab',['field_name'=>'text','langs'=>$langs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('admin.layouts.includes.create_input_top_label',['field_name'=>'group'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('admin.layouts.includes.create_input_top_label',['field_name'=>'key'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('admin.layouts.includes.create_check',['field_name'=>'is_active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="text-right">
                <button type="submit" class="btn btn-primary"><i class="icon-database-insert mr-2"></i> Insert</button>
            </div>
        </div>

    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/language_line/create.blade.php ENDPATH**/ ?>