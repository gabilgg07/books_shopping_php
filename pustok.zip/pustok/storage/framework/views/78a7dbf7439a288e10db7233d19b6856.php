<div class="home-right-side">
    <div class="single-block">
        <div class="sb-custom-tab text-center">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="shop-tab" data-toggle="tab" href="#shop" role="tab" aria-controls="shop" aria-selected="true">
                        <?php echo e(__('featured.products')); ?>

                    </a>
                    <span class="arrow-icon"></span>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="men-tab" data-toggle="tab" href="#men" role="tab" aria-controls="men" aria-selected="true">
                        <?php echo e(__('new.arrivals')); ?>

                    </a>
                    <span class="arrow-icon"></span>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="woman-tab" data-toggle="tab" href="#woman" role="tab" aria-controls="woman" aria-selected="false">
                        <?php echo e(__('most.view')); ?>

                    </a>
                    <span class="arrow-icon"></span>
                </li>
            </ul>
            <div class="tab-content space-db--30" id="myTabContent">
                <div class="tab-pane active" id="shop" role="tabpanel" aria-labelledby="shop-tab">
                    <div class="product-slider multiple-row slider-border-multiple-row  sb-slick-slider" data-slick-setting='{
                        "autoplay": true,
                        "autoplaySpeed": 8000,
                        "slidesToShow": 3,
                        "rows":2,
                        "dots":true
                    }' data-slick-responsive='[
                        {"breakpoint":992, "settings": {"slidesToShow": 3} },
                        {"breakpoint":768, "settings": {"slidesToShow": 2} },
                        {"breakpoint":480, "settings": {"slidesToShow": 1} },
                        {"breakpoint":320, "settings": {"slidesToShow": 1} }
                    ]'>
                        <?php $__currentLoopData = $featureds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-slide">
                            <div class="product-card">
                                <div class="product-header">
                                    <a href="" class="author">
                                        <?php echo e($book->author); ?>

                                    </a>
                                    <h3><a href="<?php echo e(route('client.shop.details', $book->id)); ?>"><?php echo e(Str::limit($book->title,18)); ?></a>
                                    </h3>
                                </div>
                                <div class="product-card--body">
                                    <div class="card-image">
                                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="<?php echo e($book->slug); ?> 1">
                                        <div class="hover-contents">
                                            <a href="<?php echo e(route('client.shop.details', $book->id)); ?>" class="hover-image">
                                                <?php
                                                $imgHover = $book->images()->first() !== null ?
                                                $book->images()->first()->image :
                                                $book->mainImage()->image;
                                                ?>
                                                <img src="<?php echo e(asset($imgHover)); ?>" alt="<?php echo e($book->slug); ?> 2">
                                            </a>
                                            <div class="hover-btns">
                                                <a href="<?php echo e(route('client.cart.add', $book->id)); ?>" class="single-btn">
                                                    <i class="fas fa-shopping-basket"></i>
                                                </a>

                                                <a href="#" data-toggle="modal" data-target="#quickModal" data-url="<?php echo e(route('client.shop.getDetails', $book->id)); ?>" class="single-btn detail_modal">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="price-block">
                                        <?php if($book->campaign): ?>
                                        <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($book->price-($book->price*$book->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                                        <del class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></del>
                                        <span class="price-discount"><?php echo e($book->campaign->discount_percent); ?>%</span>
                                        <?php else: ?>
                                        <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="tab-pane" id="men" role="tabpanel" aria-labelledby="men-tab">
                    <div class="product-slider multiple-row slider-border-multiple-row  sb-slick-slider" data-slick-setting='{
                                    "autoplay": true,
                                    "autoplaySpeed": 8000,
                                    "slidesToShow": 3,
                                    "rows":2,
                                    "dots":true
                                    }' data-slick-responsive='[
                            {"breakpoint":992, "settings": {"slidesToShow": 3} },
                            {"breakpoint":768, "settings": {"slidesToShow": 2} },
                            {"breakpoint":480, "settings": {"slidesToShow": 1} },
                            {"breakpoint":320, "settings": {"slidesToShow": 1} }
                        ]'>
                        <?php $__currentLoopData = $new_arrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-slide">
                            <div class="product-card">
                                <div class="product-header">
                                    <a href="" class="author">
                                        <?php echo e($book->author); ?>

                                    </a>
                                    <h3><a href="<?php echo e(route('client.shop.details', $book->id)); ?>"><?php echo e(Str::limit($book->title,18)); ?></a>
                                    </h3>
                                </div>
                                <div class="product-card--body">
                                    <div class="card-image">
                                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="<?php echo e($book->slug); ?> 1">
                                        <div class="hover-contents">
                                            <a href="<?php echo e(route('client.shop.details', $book->id)); ?>" class="hover-image">
                                                <?php
                                                $imgHover = $book->images()->first() !== null ?
                                                $book->images()->first()->image :
                                                $book->mainImage()->image;
                                                ?>
                                                <img src="<?php echo e(asset($imgHover)); ?>" alt="<?php echo e($book->slug); ?> 2">
                                            </a>
                                            <div class="hover-btns">
                                                <a href="<?php echo e(route('client.cart.add', $book->id)); ?>" class="single-btn">
                                                    <i class="fas fa-shopping-basket"></i>
                                                </a>

                                                <a href="#" data-toggle="modal" data-target="#quickModal" data-url="<?php echo e(route('client.shop.getDetails', $book->id)); ?>" class="single-btn detail_modal">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="price-block">
                                        <?php if($book->campaign): ?>
                                        <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($book->price-($book->price*$book->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                                        <del class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></del>
                                        <span class="price-discount"><?php echo e($book->campaign->discount_percent); ?>%</span>
                                        <?php else: ?>
                                        <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="tab-pane" id="woman" role="tabpanel" aria-labelledby="woman-tab">
                    <div class="product-slider multiple-row slider-border-multiple-row  sb-slick-slider" data-slick-setting='{
                                    "autoplay": true,
                                    "autoplaySpeed": 8000,
                                    "slidesToShow": 3,
                                    "rows":2,
                                    "dots":true
                                }' data-slick-responsive='[
                                        {"breakpoint":992, "settings": {"slidesToShow": 3} },
                                        {"breakpoint":768, "settings": {"slidesToShow": 2} },
                                        {"breakpoint":480, "settings": {"slidesToShow": 1} },
                                        {"breakpoint":320, "settings": {"slidesToShow": 1} }
                                    ]'>

                        <?php $__currentLoopData = $most_view_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-slide">
                            <div class="product-card">
                                <div class="product-header">
                                    <a href="" class="author">
                                        <?php echo e($book->author); ?>

                                    </a>
                                    <h3><a href="<?php echo e(route('client.shop.details', $book->id)); ?>"><?php echo e(Str::limit($book->title,18)); ?></a>
                                    </h3>
                                </div>
                                <div class="product-card--body">
                                    <div class="card-image">
                                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="<?php echo e($book->slug); ?> 1">
                                        <div class="hover-contents">
                                            <a href="<?php echo e(route('client.shop.details', $book->id)); ?>" class="hover-image">
                                                <?php
                                                $imgHover = $book->images()->first() !== null ?
                                                $book->images()->first()->image :
                                                $book->mainImage()->image;
                                                ?>
                                                <img src="<?php echo e(asset($imgHover)); ?>" alt="<?php echo e($book->slug); ?> 2">
                                            </a>
                                            <div class="hover-btns">
                                                <a href="<?php echo e(route('client.cart.add', $book->id)); ?>" class="single-btn">
                                                    <i class="fas fa-shopping-basket"></i>
                                                </a>

                                                <a href="#" data-toggle="modal" data-target="#quickModal" data-url="<?php echo e(route('client.shop.getDetails', $book->id)); ?>" class="single-btn detail_modal">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="price-block">
                                        <?php if($book->campaign): ?>
                                        <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($book->price-($book->price*$book->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                                        <del class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></del>
                                        <span class="price-discount"><?php echo e($book->campaign->discount_percent); ?>%</span>
                                        <?php else: ?>
                                        <span class="price"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="single-slide">
                            <div class="product-card">
                                <div class="product-header">
                                    <a href="" class="author">
                                        Apple
                                    </a>
                                    <h3><a href="<?php echo e(route('client.shop.details',1)); ?>">iPad with
                                            Retina Display</a></h3>
                                </div>
                                <div class="product-card--body">
                                    <div class="card-image">
                                        <img src="<?php echo e(asset('client/assets/image/products/product-1.jpg')); ?>" alt="">
                                        <div class="hover-contents">
                                            <a href="<?php echo e(route('client.shop.details',1)); ?>" class="hover-image">
                                                <img src="<?php echo e(asset('client/assets/image/products/product-1.jpg')); ?>"
                                                    alt="">
                                            </a>
                                            <div class="hover-btns">
                                                <a href="cart.html" class="single-btn">
                                                    <i class="fas fa-shopping-basket"></i>
                                                </a>
                                                <a href="#" data-toggle="modal" data-target="#quickModal"
                                                    class="single-btn">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="price-block">
                                        <span class="price">£51.20</span>
                                        <del class="price-old">£51.20</del>
                                        <span class="price-discount">20%</span>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>



</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/home/includes/tab.blade.php ENDPATH**/ ?>