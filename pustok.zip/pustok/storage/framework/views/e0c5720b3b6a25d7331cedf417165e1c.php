<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\dashboard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection("content"); ?>

<div class="content">
    <?php if(session('message')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?> border-0 alert-dismissible">
        <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>