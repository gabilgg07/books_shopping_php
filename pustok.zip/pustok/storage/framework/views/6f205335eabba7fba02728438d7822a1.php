<?php $__env->startPush('theme_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\tables\datatables\datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\selects\select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\datatables_basic.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="card">
        <?php if(session('message')): ?>
        <div class="alert alert-success border-0 alert-dismissible">
            <button type="button" class="close" data-dismiss="alert"><span>×</span></button>
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card-header header-elements-inline">
            <h5 class="card-title">Language Lines</h5>
            <div class="header-elements">
                <div class="list-icons">
                    <a href="<?php echo e(route('manager.language_line.create')); ?>" class="btn btn-success btn-sm"><i class="icon-plus-circle2 mr-2"></i> Add Language Line</a>
                </div>
            </div>
        </div>
        <table class="table table-bordered datatable-basic">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Group</th>
                    <th>Key</th>
                    <th>Text</th>
                    <th>Is Deleted</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($language->id); ?></td>
                    <td><?php echo e($language->group); ?></td>
                    <td><?php echo e($language->key); ?></td>
                    <td><?php echo e(json_encode($language->text)); ?></td>
                    <td>
                        <?php if(!$language->is_deleted): ?>
                        <span class="badge badge-success">No</span>
                        <?php else: ?>
                        <span class="badge badge-danger">Yes</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="list-icons">
                            <a href="<?php echo e(route('manager.language_line.edit', $language->id)); ?>" class="btn btn-info d-flex align-items-center"><i class="mi-info mr-2"></i> Info</a>
                            <a href="<?php echo e(route('manager.language_line.edit', $language->id)); ?>" class="btn btn-warning d-flex align-items-center"><i class="icon-pencil3 mr-2"></i>
                                Edit</a>
                            <a href="<?php echo e(route('manager.language_line.destroy', $language->id)); ?>" class="btn btn-outline-danger d-flex align-items-center"><i class="mi-delete mr-2"></i>
                                Delete</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/languageLine/index.blade.php ENDPATH**/ ?>