<div class="col-lg-<?php echo e($col); ?>">
    <div class="card border-<?php echo e($color); ?>">
        <div class="card-header bg-<?php echo e($color); ?> header-elements-inline">
            <span class="card-title font-weight-semibold"><?php echo e(Str::headline($field_name)); ?></span>
            <div class="header-elements">
                <div class="list-icons">
                    <a class="list-icons-item" data-action="collapse"></a>
                </div>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="nav nav-sidebar my-2">
                <?php $__currentLoopData = $field_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $r_class = $colors[rand(0,
                count($colors)-1)];
                ?>
                <!-- <li class="nav-item"> -->
                <!-- <div
                    class="nav-link text-<?php echo e($r_class); ?> <?php echo e(array_key_last($field_value)!=$lang?'border-bottom-1 border-bottom-dashed':''); ?>"> -->
                <?php echo $item; ?>

                <!-- <span class="font-size-sm text-right font-weight-normal ml-auto text-<?php echo e($r_class); ?>-300"
                            style="min-width: 50px;"><?php echo e($lang); ?></span> -->
                <!-- </div> -->
                <!-- </li> -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/lang_tab_editor.blade.php ENDPATH**/ ?>