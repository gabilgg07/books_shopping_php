<div class="modal-content">
    <button type="button" class="close modal-close-btn ml-auto" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <div class="product-details-modal">
        <div class="row">
            <div class="col-lg-5">
                <!-- Product Details Slider Big Image-->
                <div class="product-details-slider sb-slick-slider arrow-type-two" data-slick-setting='{
                            "slidesToShow": 1,
                            "arrows": false,
                            "fade": true,
                            "draggable": false,
                            "swipe": false,
                            "asNavFor": ".product-slider-nav"
                            }'>

                    <div class="single-slide">
                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="">
                    </div>
                    <?php if(count($book->images())): ?>
                    <?php $__currentLoopData = $book->images(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-slide">
                        <img src="<?php echo e(asset($img->image)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <!-- Product Details Slider Nav -->
                <div class="mt--30 product-slider-nav sb-slick-slider arrow-type-two" data-slick-setting='{
            "infinite":true,
              "autoplay": true,
              "autoplaySpeed": 8000,
              "slidesToShow": 4,
              "arrows": true,
              "prevArrow":{"buttonClass": "slick-prev","iconClass":"fa fa-chevron-left"},
              "nextArrow":{"buttonClass": "slick-next","iconClass":"fa fa-chevron-right"},
              "asNavFor": ".product-details-slider",
              "focusOnSelect": true
              }'>
                    <div class="single-slide">
                        <img src="<?php echo e(asset($book->mainImage()->image)); ?>" alt="">
                    </div>
                    <?php if(count($book->images())): ?>
                    <?php $__currentLoopData = $book->images(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-slide">
                        <img src="<?php echo e(asset($img->image)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-7 mt--30 mt-lg--30">
                <div class="product-details-info pl-lg--30 ">
                    <h3 class="product-title">
                        <?php echo e($book->title); ?>

                    </h3>
                    <ul class="list-unstyled">
                        <li>
                            <?php echo e(__('word.category')); ?>:
                            <a href="<?php echo e(route('client.shop.index', $book->category->slug)); ?>"
                                class="list-value font-weight-bold"> <?php echo e($book->category->title); ?></a>
                        </li>
                        <?php if($book->campaign): ?>
                        <li>
                            <?php echo e(__('word.campaign')); ?>:
                            <a href="<?php echo e(route('client.shop.index', ['campaign_id'=>$book->campaign->id])); ?>"
                                class="list-value font-weight-bold"> <?php echo e($book->campaign->title); ?></a>
                        </li>
                        <?php endif; ?>
                        <li>
                            <?php echo e(__('word.availability')); ?>: <?php if($book->count): ?>
                            <span class="list-value"><?php echo e(__('word.in_stock')); ?></span>
                            <?php else: ?>
                            <span class="list-value"><?php echo e(__('word.out_stock')); ?></span>
                            <?php endif; ?>
                        </li>
                    </ul>
                    <div class="price-block">
                        <?php if($book->campaign): ?>
                        <span
                            class="price-new"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * ($book->price-($book->price*$book->campaign->discount_percent/100)), 2, '.', '')); ?></span>
                        <del
                            class="price-old"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></del>
                        <?php else: ?>
                        <span
                            class="price-new"><?php echo e(__('symbol.currency')); ?><?php echo e(number_format($currPrice * $book->price, 2, '.', '')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="rating-widget">
                        <div class="rating-block">
                            <?php for($i = 0; $i< 5; $i++): ?> <?php if($i < (int)round($book->reviews->avg('rate'))): ?>
                                <span class="fas fa-star star_on"></span>
                                <?php else: ?>
                                <span class="fas fa-star"></span>
                                <?php endif; ?>
                                <?php endfor; ?>
                        </div>
                        <div class="review-widget">
                            <a href="">(<?php echo e((int)round($book->reviews->avg('rate'))); ?> <?php echo e(__('word.reviews')); ?>)</a>
                            <span>|</span>
                            <a href=""><?php echo e(__('review.write')); ?></a>
                        </div>
                    </div>
                    <article class="product-details-article">
                        <p>
                            <?php echo e($book->short_desc); ?>

                        </p>
                    </article>
                    <div class="add-to-cart-row">
                        <form action="<?php echo e(route('client.cart.update.modal')); ?>" class="row" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="count-input-block">
                                <span class="widget-label"><?php echo e(__('word.qty')); ?></span>
                                <input type="number" name="qty" class="form-control text-center" value="1">
                                <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                            </div>
                            <div class="add-cart-btn">
                                <button class="btn btn-outlined--primary"><span
                                        class="plus-icon">+</span><?php echo e(__('cart.add')); ?></button>
                            </div>
                        </form>
                    </div>
                    <div class="compare-wishlist-row">
                        <a href="" class="add-link"><i class="fas fa-heart"></i><?php echo e(__('wish.add')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/includes/details_modal.blade.php ENDPATH**/ ?>