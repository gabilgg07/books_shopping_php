<?php
$model_name = $index_view_model['model_name'];
$table_name = $index_view_model['table_name'];
$models = $index_view_model['models'];
?>



<?php $__env->startPush('theme_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\tables\datatables\datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\switchery.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\datatables_basic.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("page_title"); ?>
<?php echo e(Str::headline($table_name)); ?> Index
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card mb-2 d-none alert alert-dismissible" id="alert_message">
        <button type="button" class="close close-alert"><span>×</span></button>
        <span class="msg-text"></span>
    </div>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h5 class="card-title"><?php echo e(Str::headline($table_name)); ?> Index Table</h5>
            <div style="display: flex; gap: 10px;">
                <div class="box-btn">
                    <a href="<?php echo e(route('manager.'.$table_name.'.create')); ?>" type="button"
                        class="btn btn-block btn-success">
                        <i class="icon-plus-circle2 mr-2"></i> Add <?php echo e(Str::headline($model_name)); ?></a>
                </div>
                <div class="box-btn">
                    <a href="<?php echo e(route('manager.'.$table_name.'.deleteds')); ?>" class="btn btn-danger">
                        <i class="mi-delete-sweep mr-1" style="font-size: 18px;"></i>
                        Deleted <?php echo e(Str::headline($table_name)); ?> Table</a>
                </div>
            </div>
        </div>
        <table class="table table-bordered datatable-basic">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Image</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Is Active</th>
                    <th class="w-auto">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($model->id); ?></td>
                    <td width='200'>
                        <?php if($model->image): ?>
                        <img src="<?php echo e($model->image); ?>" alt="<?php echo e($model->slug); ?>" class="img-fluid w-100"
                            style="object-fit: cover; object-position: center;">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($model->created_at); ?></td>
                    <td><?php echo e($model->updated_at); ?></td>
                    <td class="text-center">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input-switchery isActive" id="<?php echo e($model->id); ?>"
                                data-fouc="" <?php echo e($model->is_active?'checked':''); ?>>
                        </label>
                    </td>
                    <td class="text-right">
                        <a href="<?php echo e(route('manager.'.$table_name.'.show', $model->id)); ?>" class="btn btn-info mb-1"><i
                                class="mi-info mr-2"></i> Info</a>
                        <a href="<?php echo e(route('manager.'.$table_name.'.edit',$model->id)); ?>" class="btn btn-warning mb-1"><i
                                class="icon-pencil3 mr-2"></i>
                            Edit</a>
                        <form onsubmit="return confirm('Are you sure?')" method="post"
                            action="<?php echo e(route('manager.'.$table_name.'.destroy', $model->id)); ?>" class="d-inline-block">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-danger"><i class="mi-delete mr-2"></i>
                                Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_js'); ?>
<script>
$(document).ready(function() {

    let ids = [];
    const url = "<?php echo e(route('manager.'.$table_name.'.change_active')); ?>";
    if ($(".isActive").length) {
        $(".datatable-basic").DataTable({
            drawCallback: function() {
                if (ids.length) {
                    ids.forEach((value, index, array) => {
                        deactiveAll(value.ids);
                    })
                }
                const alertElement = $("#alert_message");
                let msg = "";

                $(".close-alert").click(function() {
                    alertElement.addClass("d-none");
                });

                $(".datatable-basic tbody").off("click", ".isActive");
                $(".datatable-basic tbody").on("click", ".isActive", (e) => {
                    changeIsActive(e, msg, alertElement, url, ids);
                });
            },
        });
    } else {
        $(".datatable-basic").DataTable();
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/brands/index.blade.php ENDPATH**/ ?>