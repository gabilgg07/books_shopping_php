<?php $__env->startSection('title', 'Language Line Create'); ?>
<?php $__env->startPush('theme_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\switchery.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_checkboxes_radios.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="content">
    <form action="<?php echo e(route('manager.language_line.store')); ?>" method="POST" class="row">
        <?php echo csrf_field(); ?>
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs nav-tabs-solid border-0">
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item"><a href="#<?php echo e($lang->code); ?>" class="nav-link <?php echo e($key === 0 ? 'active' : ''); ?>"
                                data-toggle="tab"><?php echo e($lang->code); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <div class="tab-content">
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade <?php echo e($key === 0 ? 'show active' : ''); ?>" id="<?php echo e($lang->code); ?>">
                            <div class="card">
                                <div class="card-body">
                                    <fieldset>
                                        <div class="form-group">
                                            <label>Text:</label>
                                            <input type="text" class="form-control" name="text[<?php echo e($lang->code); ?>]"
                                                value="<?php echo e(old('text.' . $lang->code)); ?>">
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>



                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label>Group:</label>
                        <input type="text" name="group" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Key:</label>
                        <input type="text" name="key" class="form-control">
                    </div>
                    <div class="form-check form-check-switchery form-check-inline form-check-right">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input-switchery" name="is_active" data-fouc=""
                                <?php echo e(!old('_token')||old('is_active')?'checked':''); ?>>
                            Is Active?
                        </label>
                    </div>
                </div>
            </div>
            <div class="text-right">
                <button type="submit" class="btn btn-primary"><i class="icon-database-insert mr-2"></i> Insert</button>
            </div>
        </div>

    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/languageLine/create.blade.php ENDPATH**/ ?>