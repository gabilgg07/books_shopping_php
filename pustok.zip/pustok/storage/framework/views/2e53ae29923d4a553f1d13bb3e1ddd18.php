<!--=================================
    Footer Area
===================================== -->
<footer class="site-footer">
    <div class="container">
        <div class="row justify-content-between  section-padding">
            <div class=" col-xl-4 col-lg-4 col-sm-6">
                <div class="single-footer pb--40">
                    <div class="brand-footer footer-title">
                        <a href="<?php echo e(route('client.home.index')); ?>">
                            <img src="<?php echo e(asset('client/assets/image/logo--footer.png')); ?>" alt="">
                        </a>
                    </div>
                    <div class=" footer-contact">
                        <p><span class="label"><?php echo e(__('word.address')); ?>:</span><span
                                class="text"><?php echo $settings->address; ?></span></p>
                        <p><span class="label"><?php echo e(__('word.phone')); ?>:</span><span
                                class="text"><?php echo e($settings->phone); ?></span></p>
                        <p><span class="label"><?php echo e(__('word.email')); ?>:</span><span
                                class="text"><?php echo e($settings->email); ?></span></p>
                    </div>
                </div>
            </div>
            <div class=" col-xl-3 col-lg-2 col-sm-6">
                <div class="single-footer pb--40">
                    <div class="footer-title">
                        <h3><?php echo e(__('word.information')); ?></h3>
                    </div>
                    <ul class="footer-list normal-list">
                        <li><a href="<?php echo e(route('client.home.index')); ?>"><?php echo e(__('menu.home')); ?></a></li>
                        <li><a href="<?php echo e(route('client.shop.index')); ?>"><?php echo e(__('menu.shop')); ?></a></li>
                        <li><a href="<?php echo e(route('client.contact')); ?>"><?php echo e(__('menu.contact')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class=" col-xl-3 col-lg-4 col-sm-6">
                <div class="footer-title">
                    <h3><?php echo e(__('subscribe.title')); ?></h3>
                </div>
                <div class="newsletter-form mb--30">
                    <form action="./php/mail.php">
                        <input type="email" class="form-control" placeholder="<?php echo e(__('subscribe.placeholder')); ?>">
                        <button class="btn btn--primary w-100"><?php echo e(__('subscribe.btn')); ?></button>
                    </form>
                </div>
                <div class="social-block">
                    <h3 class="title"><?php echo e(__('stay.connected')); ?></h3>
                    <ul class="social-list list-inline">
                        <li class="single-social facebook"><a href="<?php echo e($settings->facebook); ?>"><i
                                    class="ion ion-social-facebook"></i></a>
                        </li>
                        <li class="single-social twitter"><a href="<?php echo e($settings->twitter); ?>"><i
                                    class="ion ion-social-twitter"></i></a></li>
                        <li class="single-social google"><a href="<?php echo e($settings->google_plus); ?>"><i
                                    class="ion ion-social-googleplus-outline"></i></a></li>
                        <li class="single-social youtube"><a href="<?php echo e($settings->youtube); ?>"><i
                                    class="ion ion-social-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <p class="copyright-heading"><?php echo e($settings->copy_heading); ?></p>
            <!-- <a href="#" class="payment-block">
                <img src="<?php echo e(asset('client/assets/image/icon/payment.png')); ?>" alt="">
            </a> -->
            <p class=" copyright-text"><?php echo $settings->copy_text; ?>

            </p>
        </div>
    </div>
</footer><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/partials/footer.blade.php ENDPATH**/ ?>