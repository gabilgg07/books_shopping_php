<?php
$model_name = $deleteds_view_model['model_name'];
$table_name = $deleteds_view_model['table_name'];
$models = $deleteds_view_model['models'];
?>



<?php $__env->startPush('theme_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\tables\datatables\datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\selects\select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\datatables_basic.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("page_title"); ?>
Deleted <?php echo e(Str::headline($table_name)); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title  d-flex justify-content-between float-none align-items-center">
                Deleted <?php echo e(Str::headline($table_name)); ?> Table
            </h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered datatable-basic">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Title</th>
                        <th>Created At</th>
                        <th>Deleted At</th>
                        <th>Image</th>
                        <th class="w-auto">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($model->id); ?></td>
                        <td>
                            <?php echo e($model->title); ?>

                            <?php if($model->parent_id==0): ?>
                            <span class="badge badge-light badge-striped badge-striped-left border-left-info">parent
                                <?php echo e($model_name); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($model->created_at); ?></td>
                        <td><?php echo e($model->deleted_at); ?></td>
                        <td width='200'>
                            <?php if($model->image): ?>
                            <img src="<?php echo e($model->image); ?>" alt="<?php echo e($model->slug); ?>" class="img-fluid w-100"
                                style="object-fit: cover; object-position: center; height:100px;">
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <a href="<?php echo e(route('manager.'.$table_name.'.show', $model->id)); ?>" class="btn btn-info mb-1"><i
                                    class="mi-info mr-2"></i>
                                Info</a>
                            <a href="<?php echo e(route('manager.'.$table_name.'.restore', $model->id)); ?>"
                                class="btn btn-success mb-1">
                                <i class="mi-restore-page mr-2"></i>
                                Restore</a>
                            <form onsubmit="return confirm('Are you sure you want permanently delete this data?')"
                                method="post"
                                action="<?php echo e(route('manager.'.$table_name.'.permanently_delete', $model->id)); ?>"
                                class="d-inline-block">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" style="min-width:170px;" class="btn btn-danger mb-1"><i
                                        class="mi-delete-forever mr-2"></i>Permanently Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/categories/deleteds.blade.php ENDPATH**/ ?>