<li class="menu-item <?php echo e(request()->routeIs('client.home.index') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('client.home.index')); ?>">Home </a>

</li>
<!-- Shop -->
<!-- <li class="menu-item <?php echo e(request()->routeIs('client.shop.index') || request()->routeIs('client.shop.details') ? 'active' : ''); ?>"> -->
<li class="menu-item <?php echo e(request()->routeIs('client.shop.*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('client.shop.index')); ?>">Shop </a>

</li>


<li class="menu-item <?php echo e(request()->routeIs('client.contact') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('client.contact')); ?>">Contact</a>
</li><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/includes/nav.blade.php ENDPATH**/ ?>