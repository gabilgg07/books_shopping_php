<?php
$isEditor = $isEditor ?? false;
?>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-tabs nav-tabs-solid border-0">
            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item border <?php echo e($errors->has($field_name.'.' . $lang->code)?'border-danger':''); ?>"><a
                    href="#<?php echo e($field_name.$lang->code); ?>" class="nav-link <?php echo e($key === 0 ? 'active' : ''); ?>"
                    data-toggle="tab"><?php echo e($lang->code); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="tab-content">
            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab-pane fade <?php echo e($key === 0 ? 'show active' : ''); ?>" id="<?php echo e($field_name.$lang->code); ?>">
                <div class="card">
                    <div class="card-body">
                        <fieldset>
                            <div class="form-group">
                                <label><?php echo e(Str::headline($field_name)); ?>:</label>

                                <textarea class="<?php echo e($isEditor?'summernote':'form-control'); ?>"
                                    name="<?php echo e($field_name); ?>[<?php echo e($lang->code); ?>]"><?php echo e(old($field_name.'.' . $lang->code, array_key_exists($lang->code, $field_value)?$field_value[$lang->code]:'')); ?></textarea>

                                <?php $__errorArgs = [$field_name.'.' . $lang->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger ml-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/edit_lang_tab_area.blade.php ENDPATH**/ ?>