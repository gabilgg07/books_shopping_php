<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="shortcut icon" type="assets/image/x-icon" href="<?php echo e(asset('admin/global_assets/admin_favicon.png')); ?>">
<title><?php echo e(config('app.name','Pustok')); ?> <?php echo $__env->yieldPushContent('page_title', 'Admin Panel'); ?></title>


<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/global_assets\css\icons\icomoon\styles.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/global_assets\css\icons\material\styles.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/assets/css\bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/assets/css\bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/assets/css\layout.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/assets/css\components.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/assets/css\colors.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/assets/css/additional.css')); ?>" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->

<!-- Core JS files -->
<script src="<?php echo e(asset('admin/global_assets\js\main\jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\main\bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\loaders\blockui.min.js')); ?>"></script>
<!-- /core JS files -->

<!-- Theme JS files -->
<?php echo $__env->yieldPushContent('theme_js'); ?>

<script src="<?php echo e(asset('admin/assets/js\app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('page_js'); ?>
<!-- /theme JS files --><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/partials/head.blade.php ENDPATH**/ ?>