<?php
$default_value=$default_value ?? '';
?>
<div class="form-group">
    <label for="<?php echo e($field_name); ?>">Select <?php echo e(Str::headline($field_label)); ?>:</label>
    <select class="custom-select form-control-border" id="<?php echo e($field_name); ?>" name="<?php echo e($field_name); ?>"
        value="<?php echo e(old($field_name, $field_value)); ?>">
        <option value="<?php echo e($default_value); ?>"><?php echo e(Str::headline($field_label)); ?></option>
        <?php $__currentLoopData = $select_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if((int)old($field_name, $field_value)===$item->id): echo 'selected'; endif; ?>
            value="<?php echo e($item->id); ?>"
            ><?php echo e($item->$shown_field); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = [$field_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger ml-2"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/edit_select_input.blade.php ENDPATH**/ ?>