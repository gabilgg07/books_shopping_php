<?php
$col = $col ?? 3;
$upper = $upper ?? false;
?>

<div class="col-lg-<?php echo e($col); ?> col-md-<?php echo e($col===3?'4':'6'); ?>">
    <div class="card border-left-3 border-left-<?php echo e($color); ?>-400 border-right-3 border-right-<?php echo e($color); ?>-400 rounded-0">
        <div class="card-header">
            <h6 class="card-title">
                <span class="font-weight-semibold"><?php echo e(Str::headline($field_name)); ?>:</span>
            </h6>
        </div>
        <div class="card-body">
            <code class="text-<?php echo e($color); ?>"
                style="font-size: 20px;"><?php echo e($upper ? Str::upper($field_value) : $field_value); ?></code>
        </div>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/mini_text.blade.php ENDPATH**/ ?>