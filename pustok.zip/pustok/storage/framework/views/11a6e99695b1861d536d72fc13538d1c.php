<section class="mt-4 section-margin">
    <div class="container">
        <div class="category-gallery-block">
            <a href="<?php echo e(route('client.shop.index', ['slug'=>$categories['single']->slug])); ?>" class="single-block hr-large">
                <img src="<?php echo e(asset($categories['single']->image)); ?>" alt="<?php echo e($categories['single']->slug); ?>">
            </a>
            <div class=" single-block inner-block-wrapper">
                <?php $__currentLoopData = $categories['galery']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('client.shop.index', ['slug'=>$category->slug])); ?>" class="single-image <?php echo e($key===0||$key===3?'mid':'small'); ?>-image">
                    <img src="<?php echo e(asset($category->image)); ?>" alt="<?php echo e($category->slug); ?>">
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <a href=" #" class="single-image small-image">
                    <img src="<?php echo e(asset('client/assets/image/others/cat-gal-small.png')); ?>" alt="">
                </a>
                <a href=" #" class="single-image small-image">
                    <img src="<?php echo e(asset('client/assets/image/others/cat-gal-small-2.jpg')); ?>" alt="">
                </a>
                <a href="#" class="single-image mid-image">
                    <img src="<?php echo e(asset('client/assets/image/others/cat-gal-mid-2.png')); ?>" alt="">
                </a> -->
            </div>
        </div>
    </div>
</section><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/home/includes/galery.blade.php ENDPATH**/ ?>