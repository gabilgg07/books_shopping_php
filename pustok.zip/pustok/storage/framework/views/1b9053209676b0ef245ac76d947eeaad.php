<?php
$model_name = $deleteds_view_model['model_name'];
$table_name = $deleteds_view_model['table_name'];
$models = $deleteds_view_model['models'];
?>



<?php $__env->startPush('theme_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\tables\datatables\datatables.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\datatables_basic.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("page_title"); ?>
Deleted <?php echo e(Str::headline($table_name)); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card mb-2 d-none alert alert-dismissible" id="alert_message">
        <button type="button" class="close close-alert"><span>×</span></button>
        <span class="msg-text"></span>
    </div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title  d-flex justify-content-between float-none align-items-center">
                Deleted <?php echo e(Str::headline($table_name)); ?> Table
            </h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered datatable-basic">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Code</th>
                        <th>Country</th>
                        <th>Deleted At</th>
                        <th>Image</th>
                        <th class="w-auto">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($model->id); ?></td>
                        <td><?php echo e(Str::upper($model->code)); ?></td>
                        <td><?php echo e(Str::headline($model->country)); ?></td>
                        <td><?php echo e($model->deleted_at); ?></td>
                        <td width='200'>
                            <?php if($model->image): ?>
                            <img src="<?php echo e($model->image); ?>" alt="<?php echo e($model_name.'-'.$model->id); ?>" class="img-fluid border-1">
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <a href="<?php echo e(route('manager.'.$table_name.'.show', $model->id)); ?>" class="btn btn-info"><i class="mi-info mr-2"></i> Info</a>
                            <a href="<?php echo e(route('manager.'.$table_name.'.restore', $model->id)); ?>" class="btn btn-success">
                                <i class="mi-restore-page mr-3"></i>
                                Restore</a>
                            <form onsubmit="return confirm('Are you sure you want permanently delete this data?')" method="post" action="<?php echo e(route('manager.'.$table_name.'.permanently_delete', $model->id)); ?>" class="d-inline-block">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" style="width:fit-content;" class="btn btn-danger ml-1"><i class="mi-delete-forever mr-2"></i>Permanently Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/langs/deleteds.blade.php ENDPATH**/ ?>