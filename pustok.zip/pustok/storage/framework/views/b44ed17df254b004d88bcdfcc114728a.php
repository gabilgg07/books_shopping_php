<?php
$model_name = $show_view_model['model_name'];
$model = $show_view_model['model'];
$created_by_user = $show_view_model['created_by_user'];
$color_classes = $show_view_model['color_classes'];
?>



<?php $__env->startPush("page_title"); ?>
<?php echo e(Str::headline($model_name)); ?> Details
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="d-flex align-items-start flex-column flex-md-row">
        <div class="w-100 overflow-auto order-2 order-md-1">
            <div class="card">
                <div class="card-body row">
                    <div class="col-md-12">

                        <h4 class="font-weight-semibold mb-1 d-flex justify-content-between align-items-center">
                            <span class="text-default text-info">Details of
                                <?php echo e($model->id); ?> id <?php echo e(Str::headline($model_name)); ?>

                            </span>
                            <?php if($model->is_deleted): ?>
                            <span class="details_status text-danger is_deleted mr-5 border-3">
                                Deleted !!!
                            </span>
                            <?php else: ?>
                            <span class="details_status text-<?php echo e($model->is_active?'success is_active':'warning not_is_active'); ?> mr-5 border-3">
                                <?php echo e($model->is_active?"Active":"Don't Active"); ?>

                            </span>
                            <?php endif; ?>
                        </h4>
                    </div>

                    <?php echo $__env->make('admin.layouts.includes.show_user',['action_name'=>'created','model_name'=>$model_name,'user'=>$created_by_user,
                    'date'=>$model->created_at, 'color'=> $color_classes[rand(0,count($color_classes)-1)]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                    <div class="col-lg-12">
                        <div class="row">
                            <?php echo $__env->make('admin.layouts.includes.lang_tab',['color'=>$color_classes[rand(0,count($color_classes)-1)],'colors'=>$color_classes,'field_name'=>'titles','field_value'=>$show_view_model['titles']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>

                    <?php echo $__env->make('admin.layouts.includes.mini_text', ['field_name'=>'discount_percent',
                    'upper'=>'',
                    'field_value'=>$model->discount_percent, 'color'=>$color_classes[rand(0,count($color_classes)-1)]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php if(array_key_exists('updated_by_user', $show_view_model)): ?>

                    <?php echo $__env->make('admin.layouts.includes.show_user',['action_name'=>'updated','model_name'=>$model_name,'user'=>$show_view_model['updated_by_user'],
                    'date'=>$model->updated_at, 'color'=> $color_classes[rand(0,count($color_classes)-1)]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endif; ?>

                    <?php if(array_key_exists('deleted_by_user', $show_view_model)): ?>

                    <?php echo $__env->make('admin.layouts.includes.show_user',['action_name'=>'deleted','model_name'=>$model_name,'user'=>$show_view_model['deleted_by_user'],
                    'date'=>$model->deleted_at, 'color'=> $color_classes[rand(0,count($color_classes)-1)]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/campaigns/show.blade.php ENDPATH**/ ?>