<?php
$class_name = $class_name ?? '';
?>

<div class="row">
    <div class="col-lg-<?php echo e($col_count); ?>">
        <img src="<?php echo e($field_value??''); ?>" alt="" id="image" class="<?php echo e($field_value?'':'d-none'); ?> <?php echo e($class_name); ?>">
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/image.blade.php ENDPATH**/ ?>