<div class="col-lg-3 col-md-4">
    <div class="card border-left-3 border-left-<?php echo e($color); ?>-400 border-right-3 border-right-<?php echo e($color); ?>-400 rounded-0">
        <div class="card-header">
            <h6 class="card-title">
                <span class="font-weight-semibold">Image:</span>
            </h6>
        </div>

        <div class="card-body">
            <img src="<?php echo e($src); ?>" class="img-fluid <?php echo e($class_name); ?>" alt="<?php echo e($alt); ?>">
        </div>
    </div>
</div><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/layouts/includes/mini_img.blade.php ENDPATH**/ ?>