<ul class="category-menu">
    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key<7): ?> <li class="cat-item <?php echo e(count($item['children'])?'has-children':''); ?>">
        <a href="<?php echo e(route('client.shop.index', $item['model']->slug)); ?>"><?php echo e($item['model']->title); ?></a>
        <?php if(count($item['children'])): ?>
        <ul class="sub-menu">
            <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('client.shop.index', $child->slug)); ?>"><?php echo e($child->title); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        </li>
        <?php else: ?>
        <li class="cat-item hidden-menu-item <?php echo e(count($item['children'])?'has-children':''); ?>">
            <a href="<?php echo e(route('client.shop.index', $item['model']->slug)); ?>"><?php echo e($item['model']->title); ?></a>
            <?php if(count($item['children'])): ?>
            <ul class="sub-menu">
                <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('client.shop.index', $child->slug)); ?>"><?php echo e($child->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($models)>8): ?>
        <li class="cat-item more_categories">
            <a href="#" class="js-expand-hidden-menu">
                <?php echo e(Str::headline(__('categories.more'))); ?>

            </a>
        </li>
        <?php endif; ?>
</ul>


<?php $__env->startPush('scripts'); ?>
<script>
$(".js-expand-hidden-menu").on("click", function(e) {
    e.preventDefault();
    $(".hidden-menu-item").toggle(500);
    var window_width = $(window).width();
    if (window_width <= 1200) {
        $(".hidden-lg-menu-item").toggle(500);
    }
    var htmlAfter = "<?php echo e(Str::headline(__('categories.close'))); ?>";
    var htmlBefore = "<?php echo e(Str::headline(__('categories.more'))); ?>";

    $(this).html(
        $(this).text() == htmlAfter ? htmlBefore : htmlAfter
    );
    $(this).toggleClass("menu-close");
});
</script>
<?php $__env->stopPush(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/components/client-categories-component.blade.php ENDPATH**/ ?>