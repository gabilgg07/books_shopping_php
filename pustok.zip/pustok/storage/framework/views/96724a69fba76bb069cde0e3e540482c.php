<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Pustok - Book Store HTML Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Use Minified Plugins Version For Fast Page Load -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('client/assets/styles/plugins.css')); ?>" />
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('client/assets/styles/main.css')); ?>" />
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('client/assets/styles/custom.css')); ?>" />
<link rel="shortcut icon" type="assets/image/x-icon" href="<?php echo e(asset('client/assets/image/favicon.ico')); ?>"><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/partials/head.blade.php ENDPATH**/ ?>