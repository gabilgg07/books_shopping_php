<li class="menu-item <?php echo e(request()->routeIs('client.home.index') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('client.home.index')); ?>"><?php echo e(__('menu.home')); ?> </a>

</li>
<!-- Shop -->
<!-- <li class="menu-item <?php echo e(request()->routeIs('client.shop.index') || request()->routeIs('client.shop.details') ? 'active' : ''); ?>"> -->
<li class="menu-item <?php echo e(request()->routeIs('client.shop.*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('client.shop.index')); ?>"><?php echo e(__('menu.shop')); ?> </a>

</li>


<li class="menu-item <?php echo e(request()->routeIs('client.contact') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('client.contact')); ?>"><?php echo e(__('menu.contact')); ?></a>
</li><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/client/layouts/partials/nav.blade.php ENDPATH**/ ?>