<?php
$model_name=$edit_view_model['model_name'];
$table_name=$edit_view_model['table_name'];
$model=$edit_view_model['model'];
$langs=$edit_view_model['langs'];
$categories=$edit_view_model['categories'];
$campaigns=$edit_view_model['campaigns'];
$json_title=$edit_view_model['json_title'];
$json_short_descs=$edit_view_model['json_short_descs'];
$json_long_descs=$edit_view_model['json_long_descs'];
$images=$edit_view_model['images'];
?>



<?php $__env->startPush("theme_js"); ?>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\switchery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\plugins\forms\styling\uniform.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('admin/global_assets\js\demo_pages\form_inputs.js')); ?>"></script>
<script>
$(window).on('load', function() {
    let imagesArr = [];
    let removed_img_ids = [];
    let placeholder = '';
    const images = $('.images');
    let imagesHtml = '';
    let dataTransfer = new DataTransfer();
    $('.img_remove').on('click', function(e) {
        const id = $(e.currentTarget).data('id');
        removed_img_ids.push(id);
        $(e.currentTarget).parent().parent().remove();
        $('.deleted_images').val(removed_img_ids);
        console.log($('.deleted_images').val());
    });

    function onRemoveSelectedImg() {
        placeholder = '';
        if (imagesArr.length) {
            dataTransfer = new DataTransfer();
            imagesArr.forEach((image, index) => {
                dataTransfer.items.add(image);
                if (index !== 0) {
                    placeholder += ', '
                }
                placeholder += image.name;
            });

            $('.filename').text(placeholder);
            $("#images_input")[0].files = dataTransfer.files;
        }
    }
    $("#images_input").change(function(e) {
        if (e.target.files.length) {

            let files = [...e.target.files];

            files.forEach(file => {

                if (imagesArr.length && imagesArr.some((value) => value.name ===
                        file.name && value.size === file.size)) {
                    console.log('This ' + file.name + ' file with size:' + file.size +
                        ' alredy added');
                } else {
                    imagesArr.push(file);
                }
            });

            dataTransfer = new DataTransfer();
            placeholder = '';
            imagesHtml = '';
            imagesArr.forEach((image, index) => {
                dataTransfer.items.add(image);
                if (index !== 0) {
                    placeholder += ', '
                }
                placeholder += image.name;
                imagesHtml += `<div class="col-lg-4 mb-2">
                                    <div class="img_box">
                                        <img src="${URL.createObjectURL(image)}" alt="" id="image" class="book_image">
                                        <span class="img_delete" data-name="${image.name}_${image.size}">
                                        <i class="icon-bin"></i></span>
                                        <div class="radio_is_main">
                                        <input type="radio" name="is_main" value="${image.name}_${image.size}" />
                                        </div>
                                    </div>
                                </div>`;
            });

            images.html(imagesHtml);

            $('.filename').text(placeholder);

            $("#images_input")[0].files = dataTransfer.files;
            $('.img_delete').on('click', function(e) {
                const name = $(e.currentTarget).data('name');
                imagesArr = imagesArr.filter((value) => value.name + '_' + value.size !== name);
                onRemoveSelectedImg();
                $(e.currentTarget).parent().parent().remove();
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("page_title"); ?>
<?php echo e(Str::headline($model_name)); ?> Edit
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<div class="content">
    <?php echo $__env->make('admin.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h5 class="card-title"><?php echo e(Str::headline($model_name)); ?> Edit</h5>
        </div>
        <?php if($errors->any()): ?>
        <div class="card-body">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="text-danger"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
    <form action="<?php echo e(route('manager.'. $table_name .'.update', $model->id)); ?>" method="POST" class="row"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div class="col-lg-6">
            <?php echo $__env->make('admin.layouts.includes.edit_lang_tab',['field_name'=>'title','langs'=>$langs,'field_value'=>$json_title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-6">
            <?php echo $__env->make('admin.layouts.includes.edit_lang_tab',['field_name'=>'short_desc','langs'=>$langs,'field_value'=>$json_short_descs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-12">
            <?php echo $__env->make('admin.layouts.includes.edit_lang_tab',['field_name'=>'long_desc','langs'=>$langs,'field_value'=>$json_long_descs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('admin.layouts.includes.edit_select_input',['field_label'=>'Category','field_name'=>'category_id','select_items'=>$categories,'shown_field'=>'title','field_value'=>$model->category_id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('admin.layouts.includes.edit_select_input',['field_label'=>'Campaign','field_name'=>'campaign_id','select_items'=>$campaigns,'shown_field'=>'title','field_value'=>$model->campaign_id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('admin.layouts.includes.edit_check',['field_name'=>'is_active','field_value'=>$model->is_active], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('admin.layouts.includes.edit_num_input',['field_name'=>'count',
                    'field_value'=>$model->count,'step'=>'1', 'colLbl'=>2,
                    'colInput'=>10]
                    , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('admin.layouts.includes.edit_num_input',['field_name'=>'price','field_value'=>$model->price,'step'=>'0.01',
                    'colLbl'=>2, 'colInput'=>10], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('admin.layouts.includes.edit_input',['field_name'=>'author','field_value'=>$model->author], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-form-label col-lg-3">Upload Images and <br /> Choose main image:</label>
                        <div class="col-lg-9">
                            <input type="file" id="images_input" class="form-control-uniform-custom" data-fouc=""
                                name="images[]" multiple>
                            <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['validation.mimes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['is_main'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="validation-invalid-label"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span class="form-text text-muted">Accepted formats: gif, png, jpg, jpeg, svg, webp. Max
                                file
                                size 2Mb</span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row images">

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row">
                                <input type="hidden" name="deleted_images" class="deleted_images">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 mb-2">
                                    <div class="img_box">
                                        <img src="<?php echo e(asset($image->image)); ?>" alt="" class="book_image">
                                        <span class="img_delete img_remove" data-id="<?php echo e($image->id); ?>">
                                            <i class="icon-bin"></i>
                                        </span>
                                        <div class="radio_is_main">
                                            <input type="radio" name="is_main" value="<?php echo e($image->id); ?>"
                                                <?php echo e($image->is_main ? 'checked' : ''); ?>>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="text-right">
                <button type="submit" class="btn btn-primary"><i class="icon-database-edit2 mr-2"></i> Update</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Desktop/ADAS/final_project/books_shopping_php/pustok/resources/views/admin/books/edit.blade.php ENDPATH**/ ?>