@php
$class_name = $class_name ?? '';
@endphp

<div class="row">
    <div class="col-lg-{{$col_count}}">
        <img src="{{$field_value??''}}" alt="" id="image" class="{{$field_value?'':'d-none'}} {{$class_name}}">
    </div>
</div>