<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Pustok - Book Store HTML Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Use Minified Plugins Version For Fast Page Load -->
<link rel="stylesheet" type="text/css" media="screen" href="{{asset('client/assets/styles/plugins.css')}}" />
<link rel="stylesheet" type="text/css" media="screen" href="{{asset('client/assets/styles/main.css')}}" />
<link rel="stylesheet" type="text/css" media="screen" href="{{asset('client/assets/styles/custom.css')}}" />
<link rel="shortcut icon" type="assets/image/x-icon" href="{{asset('client/assets/image/favicon.ico')}}">