<!-- Use Minified Plugins Version For Fast Page Load -->
<script src="{{asset('client/assets/js/plugins.js')}}"></script>
<script src="{{asset('client/assets/js/ajax-mail.js')}}"></script>
@stack("scripts")
<script src="{{asset('client/assets/js/custom.js')}}"></script>