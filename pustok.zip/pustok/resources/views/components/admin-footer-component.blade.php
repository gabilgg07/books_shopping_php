<div class="navbar navbar-expand-lg navbar-light">
    <div class="navbar-collapse collapse" id="navbar-footer">
        <span class="navbar-text">
            &copy; {{date('Y')}}. <a href="#">Pustok Admin Panel</a> by <a href="https://gabilgurbanov.com"
                target="_blank">Qabil Qurbanov</a>
        </span>

        <ul class="navbar-nav ml-lg-auto">
            <li class="nav-item"><a href="https://github.com/gabilgg07" class="navbar-nav-link" target="_blank"><i
                        class="icon-lifebuoy mr-2"></i> Support</a></li>
            <li class="nav-item"><a href="https://github.com/gabilgg07/books_shopping_php" class="navbar-nav-link"
                    target="_blank"><i class="icon-file-text2 mr-2"></i> Docs</a>
            </li>
        </ul>
    </div>
</div>