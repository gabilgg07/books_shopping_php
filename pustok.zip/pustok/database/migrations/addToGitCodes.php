<!-- timestamps -->

<!-- public function timestamps($precision = 0)
    {
        $this->boolean('is_active')->default(1);

        $this->timestamp('created_at', $precision)->nullable();
        $this->unsignedBigInteger('created_by_user_id')->default(0);

        $this->timestamp('updated_at', $precision)->nullable();
        $this->unsignedBigInteger('updated_by_user_id')->default(0);

        $this->timestamp('deleted_at', $precision)->nullable();
        $this->unsignedBigInteger('deleted_by_user_id')->default(0);
        $this->boolean('is_deleted')->default(0);
    } -->

<!-- tercume json her herf oz dilinde dusmesi ucun. vendor>spatie>laravel-translatable>src>HasTranslations.php -->
<!-- protected function asJson($value){
        return json_encode($value,JSON_UNESCAPED_UNICODE);
    } -->